// content.js — Random Ask for ChatGPT
//
// Injects a "Random" toggle into the ChatGPT composer. When active, the
// next message is NOT sent in the current conversation: it's captured,
// the composer is cleared, and a new tab opens a native ChatGPT
// "temporary chat" (?temporary-chat=true) pre-filled with the question.
// The current conversation is never touched.
//
// NOTE ON FRAGILITY: ChatGPT's DOM and URL behavior are not public APIs
// and can change without notice. The selectors below use the most
// stable anchors available today (test ids OpenAI uses for their own
// automated testing). If the toggle stops appearing, or the temporary
// chat stops auto-sending, this is the first place to check.

(function () {
  const TOGGLE_ID = "random-ask-toggle";
  let randomAskActive = false;

  // ---- DOM lookup -------------------------------------------------------

  function findSendButton() {
    return (
      document.querySelector('[data-testid="send-button"]') ||
      document.querySelector('button[aria-label="Send message"]') ||
      document.querySelector('button[aria-label="Envoyer la requête"]')
    );
  }

  function findEditor() {
    // Recent ChatGPT composer is a contenteditable div; older versions
    // used a <textarea>. Support both.
    return document.querySelector("#prompt-textarea");
  }

  function getEditorText(editor) {
    if (!editor) return "";
    return "value" in editor ? editor.value : editor.innerText;
  }

  function clearEditor(editor) {
    if (!editor) return;
    if ("value" in editor) {
      editor.value = "";
      editor.dispatchEvent(new Event("input", { bubbles: true }));
    } else {
      editor.innerText = "";
      editor.dispatchEvent(new InputEvent("input", { bubbles: true }));
    }
  }

  // ---- Toggle UI ----------------------------------------------------------

  function buildToggle() {
    const btn = document.createElement("button");
    btn.id = TOGGLE_ID;
    btn.type = "button";
    btn.className = "random-ask-toggle";
    btn.title = "Random Ask — pose ta question sans polluer ton historique";
    btn.innerHTML =
      '<span class="random-ask-icon">🔀</span><span class="random-ask-label">Random</span>';
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      randomAskActive = !randomAskActive;
      btn.classList.toggle("is-active", randomAskActive);
    });
    return btn;
  }

  function injectToggle() {
    if (document.getElementById(TOGGLE_ID)) return;
    const sendBtn = findSendButton();
    if (!sendBtn || !sendBtn.parentElement) return;
    sendBtn.parentElement.insertBefore(buildToggle(), sendBtn);
  }

  // ---- Send interception --------------------------------------------------

  function showLimitNotice() {
    const existing = document.getElementById("random-ask-notice");
    if (existing) existing.remove();
    const notice = document.createElement("div");
    notice.id = "random-ask-notice";
    notice.className = "random-ask-notice";
    notice.textContent =
      "Limite des 5 essais gratuits atteinte — clique sur l'icône Random Ask dans la barre d'extensions pour débloquer.";
    document.body.appendChild(notice);
    setTimeout(() => notice.remove(), 6000);
  }

  function deactivateToggle() {
    randomAskActive = false;
    const toggle = document.getElementById(TOGGLE_ID);
    if (toggle) toggle.classList.remove("is-active");
  }

  function handleSend(e) {
    if (!randomAskActive) return;
    const editor = findEditor();
    const text = getEditorText(editor).trim();
    if (!text) return;

    e.preventDefault();
    e.stopImmediatePropagation();

    chrome.runtime.sendMessage({ type: "RANDOM_ASK_SEND", text }, (res) => {
      if (!res || !res.ok) {
        showLimitNotice();
        return;
      }
      clearEditor(editor);
      deactivateToggle();
    });
  }

  function attachInterceptors() {
    const sendBtn = findSendButton();
    if (sendBtn && !sendBtn.dataset.randomAskBound) {
      sendBtn.dataset.randomAskBound = "true";
      sendBtn.addEventListener("click", handleSend, true);
    }
    const editor = findEditor();
    if (editor && !editor.dataset.randomAskBound) {
      editor.dataset.randomAskBound = "true";
      editor.addEventListener(
        "keydown",
        (ev) => {
          if (ev.key === "Enter" && !ev.shiftKey) handleSend(ev);
        },
        true
      );
    }
  }

  // ---- Auto-send fallback for the temporary-chat tab -----------------------
  // ?temporary-chat=true&q=... usually auto-sends the prefilled question.
  // This behavior is undocumented and has changed before, so if after a
  // few seconds the question is still sitting in the composer, send it.
  function maybeAutoSendPrefilled() {
    const params = new URLSearchParams(location.search);
    if (params.get("temporary-chat") !== "true" || !params.get("q")) return;

    let attempts = 0;
    const timer = setInterval(() => {
      attempts++;
      const editor = findEditor();
      const sendBtn = findSendButton();
      if (editor && sendBtn && !sendBtn.disabled && getEditorText(editor).trim()) {
        sendBtn.click();
        clearInterval(timer);
      }
      if (attempts > 20) clearInterval(timer); // give up after ~10s
    }, 500);
  }

  // ---- Boot ------------------------------------------------------------

  function tick() {
    injectToggle();
    attachInterceptors();
  }

  // ChatGPT is a single-page app: the composer is torn down and rebuilt
  // on navigation, so keep watching the DOM instead of running once.
  const observer = new MutationObserver(tick);
  observer.observe(document.body, { childList: true, subtree: true });
  tick();
  maybeAutoSendPrefilled();
})();

// background.js — Random Ask service worker

const FREE_LIMIT = 5;

async function getState() {
  return chrome.storage.local.get({
    randomAsk_usageCount: 0,
    randomAsk_unlocked: false,
  });
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "RANDOM_ASK_SEND") {
    handleSend(message.text).then(sendResponse);
    return true; // keep the channel open for the async response
  }
  if (message.type === "GET_STATUS") {
    getState().then((s) =>
      sendResponse({
        unlocked: s.randomAsk_unlocked,
        remaining: Math.max(0, FREE_LIMIT - s.randomAsk_usageCount),
      })
    );
    return true;
  }
  if (message.type === "REDEEM_CODE") {
    redeemCode(message.code).then(sendResponse);
    return true;
  }
});

async function handleSend(text) {
  const state = await getState();
  const atLimit =
    !state.randomAsk_unlocked && state.randomAsk_usageCount >= FREE_LIMIT;
  if (atLimit) return { ok: false, reason: "limit_reached" };

  if (!state.randomAsk_unlocked) {
    await chrome.storage.local.set({
      randomAsk_usageCount: state.randomAsk_usageCount + 1,
    });
  }

  const url =
    "https://chatgpt.com/?temporary-chat=true&q=" + encodeURIComponent(text);
  await chrome.tabs.create({ url, active: true });
  return { ok: true };
}

// ---- Chariow unlock ------------------------------------------------------
// Même schéma que DoneBell : lien de paiement Chariow → un code s'affiche
// après paiement → l'utilisateur le colle ici → validation via l'API
// Chariow. Le bloc ci-dessous est un point d'intégration, PAS une vraie
// validation — brancher le vrai endpoint/clé avant de publier.

async function redeemCode(code) {
  const trimmed = (code || "").trim();
  if (trimmed.length < 4) {
    return { ok: false, error: "invalid_format" };
  }

  // TODO: remplacer par le vrai appel à l'API Chariow, par ex. :
  // const res = await fetch("https://api.chariow.com/.../verify", {
  //   method: "POST",
  //   headers: { "Content-Type": "application/json" },
  //   body: JSON.stringify({ code: trimmed }),
  // });
  // const data = await res.json();
  // const valid = data.valid === true;

  const valid = false; // <- à remplacer par le vrai résultat de l'API

  if (valid) {
    await chrome.storage.local.set({ randomAsk_unlocked: true });
  }
  return { ok: valid, error: valid ? null : "invalid_code" };
}

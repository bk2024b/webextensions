const buyLink = document.getElementById("buy-link");
const statusEl = document.getElementById("status");
const unlockSection = document.getElementById("unlock-section");
const form = document.getElementById("code-form");
const input = document.getElementById("code-input");
const feedback = document.getElementById("code-feedback");

// TODO: remplacer par le vrai lien de paiement Chariow pour Random Ask.
buyLink.href = "https://chariow.com/REMPLACER-PAR-LE-LIEN-RANDOM-ASK";

function render(status) {
  if (status.unlocked) {
    statusEl.textContent = "Premium débloqué — utilisation illimitée.";
    unlockSection.style.display = "none";
  } else {
    statusEl.textContent = `${status.remaining} utilisation(s) gratuite(s) restante(s) sur 5.`;
    unlockSection.style.display = "block";
  }
}

chrome.runtime.sendMessage({ type: "GET_STATUS" }, render);

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const code = input.value.trim();
  if (!code) return;
  feedback.textContent = "Vérification…";
  chrome.runtime.sendMessage({ type: "REDEEM_CODE", code }, (res) => {
    if (res && res.ok) {
      feedback.textContent = "Débloqué, merci !";
      input.value = "";
      chrome.runtime.sendMessage({ type: "GET_STATUS" }, render);
    } else {
      feedback.textContent = "Code invalide.";
    }
  });
});

# Random Ask for ChatGPT — v0.1.0 (MVP)

Extension mono-fonction : une case "Random" dans la barre de saisie de
ChatGPT. Quand elle est activée, le message envoyé n'atterrit pas dans la
conversation en cours — il part dans un chat temporaire natif de ChatGPT
(`?temporary-chat=true`), ouvert dans un nouvel onglet. La conversation en
cours n'est jamais touchée.

## Installer en local (mode développeur)

1. `chrome://extensions`
2. Activer "Mode développeur" (en haut à droite)
3. "Charger l'extension non empaquetée" → sélectionner ce dossier
4. Ouvrir chatgpt.com — le bouton **Random** apparaît à côté du bouton d'envoi

## Comment ça marche

- `content.js` injecte le toggle et intercepte le clic sur "Envoyer" (et la
  touche Entrée) quand Random est actif.
- Le texte est capturé, le champ de saisie est vidé, et `background.js`
  ouvre `https://chatgpt.com/?temporary-chat=true&q=<question>` dans un
  nouvel onglet.
- Le compteur des 5 essais gratuits vit dans `chrome.storage.local`
  (`randomAsk_usageCount`, `randomAsk_unlocked`). Pas de compte utilisateur.

## Ce qui est volontairement une hypothèse à valider

Deux choix ont été faits pour cette v1, faute d'indication contraire — à
ajuster si besoin :

- **Nouvel onglet plutôt que réutiliser l'onglet courant** : ça évite de
  faire quitter la conversation en cours à l'utilisateur, au prix d'un
  changement d'onglet.
- **Le toggle se désactive automatiquement après chaque envoi** (repasse
  à l'état "off"), plutôt que de rester actif tant qu'on ne le décoche pas.

## Points fragiles à surveiller

- `?temporary-chat=true&q=...` est un comportement observé, pas une API
  documentée par OpenAI — il peut changer sans préavis. `content.js` a un
  filet de sécurité (`maybeAutoSendPrefilled`) qui clique lui-même sur
  Envoyer si le texte pré-rempli n'est pas parti tout seul au bout de
  ~10 secondes.
- Les sélecteurs (`[data-testid="send-button"]`, `#prompt-textarea`)
  sont les ancres les plus stables actuellement disponibles, mais
  ChatGPT change son DOM régulièrement. Si le bouton Random n'apparaît
  plus, c'est le premier endroit à vérifier.
- Le compteur de 5 essais gratuits est stocké localement : une
  désinstallation/réinstallation ou un nettoyage du storage le remet à
  zéro. Décision assumée, cohérente avec l'absence de compte utilisateur.

## À brancher avant publication

- **`background.js` → `redeemCode()`** : contient un point d'intégration
  clairement marqué (TODO) pour l'appel réel à l'API Chariow. Le code
  actuel ne valide jamais rien tant que le vrai endpoint n'est pas branché.
- **`popup/popup.js` → `buyLink.href`** : remplacer par le vrai lien de
  paiement Chariow pour Random Ask.
- **Icônes** (`icons/*.png`) : ce sont des placeholders générés
  (violet + flèches croisées) — à remplacer par la vraie identité
  visuelle avant publication sur le Chrome Web Store.

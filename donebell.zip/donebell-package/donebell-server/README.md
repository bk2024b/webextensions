# DoneBell — relais de licence (Chariow)

Ce dossier est un petit projet Vercel séparé de l'extension. Son seul rôle :
recevoir un code depuis l'extension, le vérifier auprès de l'API Chariow
avec la clé secrète, et répondre `{ valid: true }` ou `{ valid: false }`.
La clé secrète Chariow ne doit **jamais** être mise dans le code de
l'extension — elle ne vit que côté serveur, ici.

## 1. Avant de déployer : confirmer l'endpoint Chariow

Le fichier `api/verify-license.js` contient une URL et un parsing de
réponse à titre de point de départ (`CHARIOW_VERIFY_URL`, condition
`isValid`). Va dans ton tableau de bord Chariow → **Réglages → Développeur
→ Documentation API** pour récupérer :
- l'URL exacte de l'endpoint de vérification/activation de licence,
- la forme exacte du corps de requête et de la réponse.

Ajuste `api/verify-license.js` en conséquence avant de déployer en prod.

## 2. Déployer sur Vercel

```bash
npm i -g vercel
cd donebell-server
vercel login
vercel
```

## 3. Ajouter la clé API Chariow

Dans Chariow : **Réglages → Développeur → API Keys → Créer une clé**.

```bash
vercel env add CHARIOW_API_KEY
# colle ta clé (commence par sk_...)

vercel env add CHARIOW_VERIFY_URL
# uniquement si l'URL par défaut dans le code ne correspond pas à la tienne
```

Puis redéploie : `vercel --prod`.

## 4. Brancher l'extension dessus

Une fois déployé, Vercel te donne une URL du style
`https://donebell-server.vercel.app`. Dans l'extension, ouvre
`lib/license.js` et remplace :

```js
const RELAY_URL = "https://REMPLACE-MOI.vercel.app/api/verify-license";
```

par ton URL réelle + `/api/verify-license`.

## Tester en local

```bash
vercel dev
curl -X POST http://localhost:3000/api/verify-license \
  -H "Content-Type: application/json" \
  -d '{"code":"TEST-CODE"}'
```

/**
 * DoneBell — relais de vérification de licence (Vercel serverless function)
 *
 * Reçoit un code depuis l'extension, le vérifie auprès de Chariow avec la
 * clé API secrète (jamais exposée côté client), et répond juste
 * { valid: true|false } à l'extension.
 *
 * ⚠️ À CONFIGURER AVANT DE DÉPLOYER :
 * 1. Récupère ta clé API Chariow : Chariow > Réglages > Développeur > API Keys.
 * 2. Confirme l'URL exacte et le format de réponse de l'endpoint de
 *    vérification de licence dans la documentation développeur de TON
 *    compte Chariow (Réglages > Développeur > Documentation API). Le nom
 *    exact de l'endpoint et la forme de sa réponse n'étaient pas
 *    confirmables publiquement au moment où ce fichier a été écrit — donc
 *    CHARIOW_VERIFY_URL et la condition `isValid` plus bas sont à ajuster
 *    une fois que tu as la doc réelle sous les yeux.
 * 3. `vercel env add CHARIOW_API_KEY` (et CHARIOW_VERIFY_URL si besoin),
 *    puis déploie. Voir README.md à la racine de ce dossier.
 */

const CHARIOW_API_KEY = process.env.CHARIOW_API_KEY;
const CHARIOW_VERIFY_URL =
  process.env.CHARIOW_VERIFY_URL || "https://api.chariow.com/v1/licenses/verify"; // TODO: confirmer avec la doc Chariow

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") {
    return res.status(405).json({ valid: false, reason: "Méthode non autorisée." });
  }

  const { code } = req.body || {};
  if (!code || typeof code !== "string") {
    return res.status(400).json({ valid: false, reason: "Code manquant." });
  }

  if (!CHARIOW_API_KEY) {
    console.error("CHARIOW_API_KEY manquante dans les variables d'environnement Vercel.");
    return res.status(500).json({ valid: false, reason: "Serveur mal configuré." });
  }

  try {
    const chariowRes = await fetch(CHARIOW_VERIFY_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${CHARIOW_API_KEY}`
      },
      body: JSON.stringify({ license_key: code })
    });

    const data = await chariowRes.json().catch(() => ({}));

    // TODO: adapte cette condition à la vraie forme de réponse renvoyée par Chariow
    const isValid = chariowRes.ok && (data.valid === true || data.status === "active");

    if (!isValid) {
      return res.status(200).json({ valid: false, reason: "Code invalide, déjà utilisé, ou révoqué." });
    }

    return res.status(200).json({ valid: true });
  } catch (err) {
    console.error("Erreur d'appel à Chariow :", err);
    return res.status(502).json({ valid: false, reason: "Erreur de vérification, réessaie." });
  }
};

/**
 * DoneBell — options/options.js
 */
(async function () {
  const BUILTIN_SOUNDS = [
    { id: "default", name: "Son par défaut", premium: false },
    { id: "chime", name: "Chime", premium: true },
    { id: "pop", name: "Pop", premium: true },
    { id: "bell-deep", name: "Cloche grave", premium: true }
  ];

  // --- Éléments ---
  const statusBadge = document.getElementById("statusBadge");
  const licenseInput = document.getElementById("licenseInput");
  const activateBtn = document.getElementById("activateBtn");
  const licenseMessage = document.getElementById("licenseMessage");

  const enabledToggle = document.getElementById("enabledToggle");
  const siteCheckboxes = Array.from(document.querySelectorAll("[data-site]"));
  const volumeRange = document.getElementById("volumeRange");

  const soundSelect = document.getElementById("soundSelect");
  const importLocked = document.getElementById("importLocked");
  const importUnlocked = document.getElementById("importUnlocked");
  const soundFile = document.getElementById("soundFile");

  const profilesLocked = document.getElementById("profilesLocked");
  const profilesUnlocked = document.getElementById("profilesUnlocked");
  const profileList = document.getElementById("profileList");
  const addProfileBtn = document.getElementById("addProfileBtn");

  const advancedLocked = document.getElementById("advancedLocked");
  const advancedUnlocked = document.getElementById("advancedUnlocked");
  const notifSystem = document.getElementById("notifSystem");
  const notifInactiveOnly = document.getElementById("notifInactiveOnly");
  const notifBadge = document.getElementById("notifBadge");

  // --- Aides "profil actif = source de vérité pour sites/son/volume en premium" ---
  function effectiveValues(s) {
    return s.premium.unlocked ? s.profiles.list[s.profiles.active] : s;
  }
  function buildPatch(s, partial) {
    if (!s.premium.unlocked) return partial;
    return { profiles: { list: { [s.profiles.active]: partial } } };
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function soundLabel(s, soundId) {
    const builtin = BUILTIN_SOUNDS.find((b) => b.id === soundId);
    if (builtin) return builtin.name;
    const custom = s.customSounds[soundId];
    return custom ? "🎵 " + custom.name : soundId;
  }

  // --- Rendu ---
  function renderStatus(s) {
    const unlocked = s.premium.unlocked;
    statusBadge.textContent = unlocked ? "Premium" : "Gratuit";
    statusBadge.classList.toggle("is-premium", unlocked);

    [importLocked, profilesLocked, advancedLocked].forEach((el) => (el.hidden = unlocked));
    importUnlocked.hidden = !unlocked;
    profilesUnlocked.hidden = !unlocked;
    advancedUnlocked.hidden = !unlocked;
  }

  function renderGeneral(s) {
    enabledToggle.checked = s.enabled;
    const eff = effectiveValues(s);
    siteCheckboxes.forEach((cb) => (cb.checked = !!eff.sites[cb.dataset.site]));
    volumeRange.value = Math.round((eff.volume ?? 0.7) * 100);
  }

  function renderSoundSelect(s) {
    const eff = effectiveValues(s);
    soundSelect.innerHTML = "";

    BUILTIN_SOUNDS.forEach((snd) => {
      const locked = snd.premium && !s.premium.unlocked;
      const opt = document.createElement("option");
      opt.value = snd.id;
      opt.textContent = locked ? `${snd.name} 🔒` : snd.name;
      opt.disabled = locked;
      if (snd.id === eff.sound) opt.selected = true;
      soundSelect.appendChild(opt);
    });

    if (s.premium.unlocked) {
      Object.entries(s.customSounds).forEach(([id, snd]) => {
        const opt = document.createElement("option");
        opt.value = id;
        opt.textContent = "🎵 " + snd.name;
        if (id === eff.sound) opt.selected = true;
        soundSelect.appendChild(opt);
      });
    }
  }

  function renderProfileList(s) {
    profileList.innerHTML = "";
    Object.entries(s.profiles.list).forEach(([id, profile]) => {
      const li = document.createElement("li");
      li.className = "profile-item" + (id === s.profiles.active ? " is-active" : "");
      li.innerHTML = `
        <div>
          <div class="profile-item__name">${escapeHtml(profile.name)}</div>
          <div class="profile-item__meta">${escapeHtml(soundLabel(s, profile.sound))} · ${Math.round((profile.volume ?? 0.7) * 100)}%</div>
        </div>
        <div class="profile-item__actions">
          <button data-action="activate" data-id="${id}">Activer</button>
          <button data-action="rename" data-id="${id}">Renommer</button>
          ${id !== "default" ? `<button data-action="delete" data-id="${id}">Supprimer</button>` : ""}
        </div>`;
      profileList.appendChild(li);
    });
  }

  function renderAdvanced(s) {
    notifSystem.checked = !!s.advanced.systemNotification;
    notifInactiveOnly.checked = !!s.advanced.onlyIfTabInactive;
    notifBadge.checked = !!s.advanced.badgeCounter;
  }

  function renderAll(s) {
    renderStatus(s);
    renderGeneral(s);
    renderSoundSelect(s);
    if (s.premium.unlocked) renderProfileList(s);
    renderAdvanced(s);
  }

  let settings = await DoneBellSettings.getSettings();
  renderAll(settings);

  // --- Licence ---
  activateBtn.addEventListener("click", async () => {
    activateBtn.disabled = true;
    licenseMessage.textContent = "Vérification…";
    licenseMessage.className = "license-message";

    const result = await DoneBellLicense.activateLicense(licenseInput.value);

    activateBtn.disabled = false;
    if (result.ok) {
      licenseMessage.textContent = "Premium activé 🎉";
      licenseMessage.className = "license-message ok";
      settings = await DoneBellSettings.getSettings();
      renderAll(settings);
    } else {
      licenseMessage.textContent = result.error || "Code invalide.";
      licenseMessage.className = "license-message error";
    }
  });

  // --- Général ---
  enabledToggle.addEventListener("change", async () => {
    settings = await DoneBellSettings.setSettings({ enabled: enabledToggle.checked });
  });

  siteCheckboxes.forEach((cb) => {
    cb.addEventListener("change", async () => {
      const eff = effectiveValues(settings);
      const nextSites = { ...eff.sites, [cb.dataset.site]: cb.checked };
      settings = await DoneBellSettings.setSettings(buildPatch(settings, { sites: nextSites }));
    });
  });

  volumeRange.addEventListener("input", async () => {
    const volume = Number(volumeRange.value) / 100;
    settings = await DoneBellSettings.setSettings(buildPatch(settings, { volume }));
  });

  // --- Sons ---
  soundSelect.addEventListener("change", async () => {
    settings = await DoneBellSettings.setSettings(buildPatch(settings, { sound: soundSelect.value }));
    if (settings.premium.unlocked) renderProfileList(settings);
  });

  soundFile.addEventListener("change", async () => {
    const file = soundFile.files[0];
    if (!file) return;
    if (file.size > 1024 * 1024) {
      alert("Fichier trop lourd (1 Mo max).");
      soundFile.value = "";
      return;
    }

    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

    const id = "custom_" + Date.now();
    settings = await DoneBellSettings.setSettings({ customSounds: { [id]: { name: file.name, dataUrl } } });
    settings = await DoneBellSettings.setSettings(buildPatch(settings, { sound: id }));
    renderSoundSelect(settings);
    if (settings.premium.unlocked) renderProfileList(settings);
    soundFile.value = "";
  });

  // --- Profils ---
  addProfileBtn.addEventListener("click", async () => {
    const name = prompt("Nom du nouveau profil :");
    if (!name || !name.trim()) return;

    const id = "profile_" + Date.now();
    const base = effectiveValues(settings);
    const newProfile = { name: name.trim(), sound: base.sound, volume: base.volume, sites: { ...base.sites } };

    settings = await DoneBellSettings.setSettings({
      profiles: { list: { [id]: newProfile }, active: id }
    });
    renderAll(settings);
  });

  profileList.addEventListener("click", async (e) => {
    const btn = e.target.closest("button[data-action]");
    if (!btn) return;
    const { action, id } = btn.dataset;

    if (action === "activate") {
      settings = await DoneBellSettings.setSettings({ profiles: { active: id } });
    } else if (action === "rename") {
      const name = prompt("Nouveau nom du profil :", settings.profiles.list[id].name);
      if (name && name.trim()) {
        settings = await DoneBellSettings.setSettings({ profiles: { list: { [id]: { name: name.trim() } } } });
      }
    } else if (action === "delete") {
      if (!confirm("Supprimer ce profil ?")) return;
      const nextList = { ...settings.profiles.list };
      delete nextList[id];
      const nextActive = settings.profiles.active === id ? Object.keys(nextList)[0] || "default" : settings.profiles.active;
      settings = await DoneBellSettings.overwriteProfiles({ active: nextActive, list: nextList });
    }

    renderAll(settings);
  });

  // --- Notifications avancées ---
  notifSystem.addEventListener("change", async () => {
    settings = await DoneBellSettings.setSettings({ advanced: { systemNotification: notifSystem.checked } });
  });
  notifInactiveOnly.addEventListener("change", async () => {
    settings = await DoneBellSettings.setSettings({ advanced: { onlyIfTabInactive: notifInactiveOnly.checked } });
  });
  notifBadge.addEventListener("change", async () => {
    settings = await DoneBellSettings.setSettings({ advanced: { badgeCounter: notifBadge.checked } });
    if (!notifBadge.checked) chrome.action.setBadgeText({ text: "" });
  });
})();

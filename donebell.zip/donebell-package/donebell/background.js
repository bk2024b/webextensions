/**
 * DoneBell — background.js (service worker, Manifest V3)
 */
importScripts("lib/settings.js", "lib/license.js");

const OFFSCREEN_DOCUMENT_PATH = "offscreen/offscreen.html";

async function ensureOffscreenDocument() {
  const existing = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"]
  });
  if (existing.length > 0) return;

  await chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_PATH,
    reasons: ["AUDIO_PLAYBACK"],
    justification: "Jouer un son de notification quand une IA termine sa réponse."
  });
}

async function playSound(soundId, volume, settings) {
  await ensureOffscreenDocument();

  const isCustom = typeof soundId === "string" && soundId.startsWith("custom_");
  const customSrc = isCustom && settings.customSounds[soundId] ? settings.customSounds[soundId].dataUrl : null;

  chrome.runtime.sendMessage({
    target: "offscreen",
    type: "play-sound",
    soundId: isCustom ? null : soundId,
    customSrc,
    volume
  });
}

function siteLabel(site) {
  return { chatgpt: "ChatGPT", claude: "Claude", gemini: "Gemini" }[site] || site;
}

function getActiveProfile(settings) {
  if (!settings.premium.unlocked) {
    return { sites: settings.sites, sound: settings.sound, volume: settings.volume };
  }
  const profile = settings.profiles.list[settings.profiles.active];
  return profile || { sites: settings.sites, sound: settings.sound, volume: settings.volume };
}

async function handleResponseFinished(site, sender) {
  const settings = await DoneBellSettings.getSettings();
  if (!settings.enabled) return;

  const activeProfile = getActiveProfile(settings);
  if (!activeProfile.sites[site]) return;

  // Fonctionnalité premium : ne sonner que si l'onglet n'est pas actif/visible
  if (settings.premium.unlocked && settings.advanced.onlyIfTabInactive) {
    const tab = sender.tab;
    let windowFocused = true;
    if (tab && typeof tab.windowId === "number") {
      const win = await chrome.windows.get(tab.windowId).catch(() => null);
      windowFocused = win ? win.focused : true;
    }
    if (tab && tab.active && windowFocused) return; // l'utilisateur regarde déjà la réponse
  }

  await playSound(activeProfile.sound, activeProfile.volume, settings);

  if (settings.premium.unlocked && settings.advanced.systemNotification) {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "DoneBell",
      message: `${siteLabel(site)} a terminé sa réponse.`
    });
  }

  if (settings.premium.unlocked && settings.advanced.badgeCounter) {
    const next = (settings.pendingCount || 0) + 1;
    await DoneBellSettings.setSettings({ pendingCount: next });
    chrome.action.setBadgeText({ text: String(next) });
    chrome.action.setBadgeBackgroundColor({ color: "#D9A441" });
  }
}

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message.type === "response-finished") {
    handleResponseFinished(message.site, sender);
  }
  if (message.type === "clear-badge") {
    DoneBellSettings.setSettings({ pendingCount: 0 });
    chrome.action.setBadgeText({ text: "" });
  }
  return false;
});

// Remet le badge à zéro quand l'utilisateur revient sur un onglet surveillé
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab || !tab.url) return;
  if (/chatgpt\.com|chat\.openai\.com|claude\.ai|gemini\.google\.com/.test(tab.url)) {
    await DoneBellSettings.setSettings({ pendingCount: 0 });
    chrome.action.setBadgeText({ text: "" });
  }
});

// Revalide la licence au démarrage du navigateur / à l'installation
chrome.runtime.onStartup.addListener(() => DoneBellLicense.revalidate());
chrome.runtime.onInstalled.addListener(() => DoneBellLicense.revalidate());

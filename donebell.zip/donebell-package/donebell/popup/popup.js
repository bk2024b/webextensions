/**
 * DoneBell — popup/popup.js
 *
 * Gratuit : les pastilles de sites et le volume éditent les réglages
 * globaux (settings.sites / settings.volume).
 * Premium : ils éditent le profil actif (settings.profiles.list[active]),
 * exactement comme background.js les lit — changer de profil change donc
 * tout le lot (sites + son + volume) d'un coup.
 */
(async function () {
  const enabledToggle = document.getElementById("enabledToggle");
  const sitePills = Array.from(document.querySelectorAll(".site-pill"));
  const volumeRange = document.getElementById("volumeRange");
  const premiumLocked = document.getElementById("premiumLocked");
  const premiumUnlocked = document.getElementById("premiumUnlocked");
  const profileSelect = document.getElementById("profileSelect");
  const unlockBtn = document.getElementById("unlockBtn");
  const openOptionsBtn = document.getElementById("openOptions");

  function effectiveValues(s) {
    return s.premium.unlocked ? s.profiles.list[s.profiles.active] : s;
  }

  // Construit le patch à envoyer à setSettings, au bon endroit selon le mode
  function buildPatch(s, partial) {
    if (!s.premium.unlocked) return partial;
    const id = s.profiles.active;
    return { profiles: { list: { [id]: partial } } };
  }

  function renderSitePills(sites) {
    sitePills.forEach((btn) => {
      const site = btn.dataset.site;
      btn.classList.toggle("is-active", !!sites[site]);
    });
  }

  function renderProfiles(s) {
    profileSelect.innerHTML = "";
    Object.entries(s.profiles.list).forEach(([id, profile]) => {
      const opt = document.createElement("option");
      opt.value = id;
      opt.textContent = profile.name;
      if (id === s.profiles.active) opt.selected = true;
      profileSelect.appendChild(opt);
    });
  }

  function render(s) {
    enabledToggle.checked = s.enabled;

    const eff = effectiveValues(s);
    renderSitePills(eff.sites);
    volumeRange.value = Math.round((eff.volume ?? 0.7) * 100);

    const unlocked = s.premium.unlocked;
    premiumLocked.hidden = unlocked;
    premiumUnlocked.hidden = !unlocked;
    if (unlocked) renderProfiles(s);
  }

  let settings = await DoneBellSettings.getSettings();
  render(settings);

  enabledToggle.addEventListener("change", async () => {
    settings = await DoneBellSettings.setSettings({ enabled: enabledToggle.checked });
  });

  sitePills.forEach((btn) => {
    btn.addEventListener("click", async () => {
      const site = btn.dataset.site;
      const eff = effectiveValues(settings);
      const nextSites = { ...eff.sites, [site]: !eff.sites[site] };
      settings = await DoneBellSettings.setSettings(buildPatch(settings, { sites: nextSites }));
      renderSitePills(effectiveValues(settings).sites);
    });
  });

  volumeRange.addEventListener("input", async () => {
    const volume = Number(volumeRange.value) / 100;
    settings = await DoneBellSettings.setSettings(buildPatch(settings, { volume }));
  });

  profileSelect.addEventListener("change", async () => {
    settings = await DoneBellSettings.setSettings({
      profiles: { active: profileSelect.value }
    });
    render(settings);
  });

  unlockBtn.addEventListener("click", () => chrome.runtime.openOptionsPage());
  openOptionsBtn.addEventListener("click", () => chrome.runtime.openOptionsPage());

  // Efface le badge dès que le popup est ouvert (l'utilisateur a vu l'état)
  chrome.runtime.sendMessage({ type: "clear-badge" });
})();

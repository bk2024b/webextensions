/**
 * DoneBell — content-scripts/gemini.js
 *
 * Détecte la fin d'une génération sur gemini.google.com.
 *
 * ⚠️ Sélecteurs à vérifier/ajuster via devtools si Google change
 * l'interface — voir STOP_BUTTON_SELECTORS.
 */
(function () {
  const SITE = "gemini";

  const STOP_BUTTON_SELECTORS = [
    'button[aria-label*="Stop" i]',
    'button[aria-label*="Interrompre" i]',
    'button[aria-label*="Arrêter" i]'
  ];

  let isGenerating = false;

  function findAny(selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  function checkState() {
    const generatingNow = !!findAny(STOP_BUTTON_SELECTORS);

    if (generatingNow && !isGenerating) {
      isGenerating = true;
    } else if (!generatingNow && isGenerating) {
      isGenerating = false;
      chrome.runtime.sendMessage({ type: "response-finished", site: SITE });
    }
  }

  const observer = new MutationObserver(checkState);
  observer.observe(document.body, { childList: true, subtree: true, attributes: true });

  setInterval(checkState, 1000);
})();

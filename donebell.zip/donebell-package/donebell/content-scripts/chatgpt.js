/**
 * DoneBell — content-scripts/chatgpt.js
 *
 * Détecte la fin d'une génération sur chatgpt.com / chat.openai.com.
 *
 * Principe : pendant la génération, ChatGPT affiche un bouton "stop"
 * (icône carrée) à la place du bouton d'envoi. Dès qu'il disparaît,
 * la réponse est terminée.
 *
 * ⚠️ Les sélecteurs ci-dessous peuvent se désynchroniser au fil des
 * mises à jour de l'interface OpenAI. Si la détection s'arrête de
 * marcher : ouvrir les devtools pendant une génération, inspecter le
 * bouton stop, et mettre à jour STOP_BUTTON_SELECTORS.
 */
(function () {
  const SITE = "chatgpt";

  const STOP_BUTTON_SELECTORS = [
    '[data-testid="stop-button"]',
    'button[aria-label*="Stop" i]',
    'button[aria-label*="Arrêter" i]',
    'button[aria-label*="Interrompre" i]'
  ];

  let isGenerating = false;

  function findAny(selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  function checkState() {
    const generatingNow = !!findAny(STOP_BUTTON_SELECTORS);

    if (generatingNow && !isGenerating) {
      isGenerating = true;
    } else if (!generatingNow && isGenerating) {
      isGenerating = false;
      chrome.runtime.sendMessage({ type: "response-finished", site: SITE });
    }
  }

  const observer = new MutationObserver(checkState);
  observer.observe(document.body, { childList: true, subtree: true, attributes: true });

  // Filet de sécurité au cas où l'observer raterait une mutation
  setInterval(checkState, 1000);
})();

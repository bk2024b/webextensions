/**
 * DoneBell — offscreen/offscreen.js
 * Reçoit un ordre "play-sound" du background et joue le fichier audio
 * correspondant. Ajoute une entrée ici pour chaque nouveau son premium.
 */
const SOUND_FILES = {
  default: chrome.runtime.getURL("sounds/default.wav"),
  chime: chrome.runtime.getURL("sounds/chime.wav"),
  pop: chrome.runtime.getURL("sounds/pop.wav"),
  "bell-deep": chrome.runtime.getURL("sounds/bell-deep.wav")
};

let audioEl = null;

chrome.runtime.onMessage.addListener((message) => {
  if (message.target !== "offscreen" || message.type !== "play-sound") return;

  const src = message.customSrc || SOUND_FILES[message.soundId] || SOUND_FILES.default;
  if (!audioEl) audioEl = new Audio();

  audioEl.src = src;
  audioEl.volume = typeof message.volume === "number" ? message.volume : 0.7;
  audioEl.currentTime = 0;
  audioEl.play().catch(() => console.warn("DoneBell: lecture du son bloquée."));
});

# DoneBell

Extension qui joue un son quand ChatGPT, Claude ou Gemini terminent de
générer leur réponse. Version gratuite fonctionnelle immédiatement, palier
Premium (sons, profils, notifications avancées) débloqué par un code
acheté via Chariow.

Ce zip contient deux projets séparés :

```
donebell/           → l'extension Chrome elle-même (Manifest V3)
donebell-server/     → le petit relais Vercel qui vérifie les codes auprès de Chariow
```

## Installer l'extension pour tester (mode développeur)

1. Ouvre `chrome://extensions` dans Chrome.
2. Active le **Mode développeur** (en haut à droite).
3. Clique **Charger l'extension non empaquetée**.
4. Sélectionne le dossier `donebell/`.
5. L'icône DoneBell apparaît dans la barre d'outils.

À chaque modification du code, clique le bouton ↻ (recharger) sur la carte
de l'extension dans `chrome://extensions`.

## Ce qui marche déjà, sans rien configurer

- Détection de fin de réponse sur ChatGPT, Claude, Gemini
- Son par défaut + 3 sons premium déjà générés (chime, pop, cloche grave)
- Import de son personnalisé (premium)
- Profils (premium) : créer, renommer, supprimer, activer
- Notifications avancées (premium) : notification système, "seulement si
  onglet inactif", badge compteur
- Popup + page de paramètres complète

## Ce qu'il reste à brancher avant de vendre du Premium

1. **Déployer le relais** dans `donebell-server/` (voir son README) — il
   appelle l'API Chariow avec ta clé secrète.
2. **Mettre à jour `donebell/lib/license.js`** avec l'URL du relais une
   fois déployé (`RELAY_URL`).
3. **Configurer un produit "Licences" sur Chariow** avec génération/stock
   de codes, pour que l'endpoint de vérification ait quelque chose à
   vérifier.

## Point d'attention : les sélecteurs de détection

Les fichiers `content-scripts/chatgpt.js`, `claude.js` et `gemini.js`
détectent la fin d'une réponse en cherchant le bouton "stop" (qui remplace
le bouton d'envoi pendant la génération) via son `aria-label`. C'est une
approche solide, mais ChatGPT/Claude/Gemini changent leur interface de
temps en temps — si un site arrête de déclencher le son, ouvre les devtools
pendant une génération, inspecte le bouton stop, et ajoute son sélecteur
en haut du fichier correspondant (`STOP_BUTTON_SELECTORS`).

## Icônes et sons

Les icônes (`icons/`) et les 4 sons (`sounds/`) sont générés — un point de
départ cohérent avec la marque (cloche laiton), à remplacer par tes propres
assets quand tu veux.

## Avant de publier sur le Chrome Web Store

- Remplacer la clé API/URL du relais par les valeurs de prod
- Tester les 3 détecteurs sur les vrais sites (les sélecteurs peuvent
  demander un ajustement, voir ci-dessus)
- Vérifier les textes de la fiche Store (captures d'écran, description)

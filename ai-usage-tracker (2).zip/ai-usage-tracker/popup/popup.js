import {
  SITE_INFO,
  SITE_KEYS,
  todayKey,
  formatDuration,
  formatTime,
} from "../shared/constants.js";
import {
  getSettings,
  saveSettings,
  getStatsForDate,
  getStatsRange,
} from "../shared/storage.js";
import { isPremium } from "../shared/premium.js";

// ⚠️ Si tu configures un lien produit Chariow, renseigne-le ici : le lien
// apparaîtra alors dans l'onglet Analytics. Laisse vide pour ne rien afficher.
const CHARIOW_PRODUCT_URL = "";

const DAY_LABELS = ["dim", "lun", "mar", "mer", "jeu", "ven", "sam"];

// ---------- Onglets ----------
const tabs = document.querySelectorAll(".tab");
const panels = document.querySelectorAll(".panel");
tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    tabs.forEach((t) => t.classList.toggle("is-active", t === tab));
    tabs.forEach((t) => t.setAttribute("aria-selected", t === tab ? "true" : "false"));
    const name = tab.dataset.tab;
    panels.forEach((p) => p.classList.toggle("is-active", p.dataset.panel === name));
    if (name === "analytics") renderAnalytics();
    if (name === "settings") renderSettings();
  });
});

// ---------- Helpers ----------
function siteTotalsFromDay(day) {
  const totals = {};
  for (const site of SITE_KEYS) {
    totals[site] = (day && day[site]) || { activeSeconds: 0, messages: 0, sessions: 0, firstSessionStart: null };
  }
  return totals;
}

function sumTotals(totals) {
  return SITE_KEYS.reduce(
    (acc, site) => {
      acc.activeSeconds += totals[site].activeSeconds;
      acc.messages += totals[site].messages;
      acc.sessions += totals[site].sessions;
      return acc;
    },
    { activeSeconds: 0, messages: 0, sessions: 0 }
  );
}

function renderSiteList(container, totals) {
  container.innerHTML = "";
  for (const site of SITE_KEYS) {
    const info = SITE_INFO[site];
    const t = totals[site];
    const row = document.createElement("div");
    row.className = "site-row";
    row.innerHTML = `
      <div class="site-tick" style="background:${info.color}"></div>
      <div class="site-label">${info.label}</div>
      <div class="site-metrics">
        <span class="mono">${formatDuration(t.activeSeconds)}</span>
        <span class="mono">${t.messages} msg</span>
      </div>
    `;
    container.appendChild(row);
  }
}

// ---------- Onglet "Aujourd'hui" ----------
async function renderToday() {
  const [day, settings, premium] = await Promise.all([
    getStatsForDate(todayKey()),
    getSettings(),
    isPremium(),
  ]);
  const totals = siteTotalsFromDay(day);
  const sum = sumTotals(totals);

  document.getElementById("today-total").textContent = formatDuration(sum.activeSeconds);
  document.getElementById("today-messages").textContent = String(sum.messages);
  document.getElementById("today-sessions").textContent = String(sum.sessions);

  const starts = SITE_KEYS.map((s) => totals[s].firstSessionStart).filter(Boolean);
  const earliest = starts.length ? Math.min(...starts) : null;
  document.getElementById("today-first").textContent = formatTime(earliest);

  renderSiteList(document.getElementById("today-sites"), totals);

  const goalBlock = document.getElementById("goal-block");
  if (premium && settings.goalType && settings.goalMinutes) {
    goalBlock.hidden = false;
    const goalSeconds = settings.goalMinutes * 60;
    const pct = Math.min(100, Math.round((sum.activeSeconds / goalSeconds) * 100));
    const isMax = settings.goalType === "max";
    document.getElementById("goal-label").textContent = isMax ? "Objectif max" : "Objectif min";
    document.getElementById("goal-value").textContent =
      `${formatDuration(sum.activeSeconds)} / ${formatDuration(goalSeconds)}`;
    const fill = document.getElementById("goal-bar-fill");
    fill.style.width = `${pct}%`;
    fill.classList.toggle("is-over", isMax && sum.activeSeconds > goalSeconds);
  } else {
    goalBlock.hidden = true;
  }

  document.getElementById("premium-chip").hidden = !premium;
}

// ---------- Onglet "Analytics" ----------
async function renderAnalytics() {
  const premium = await isPremium();
  document.getElementById("analytics-locked").hidden = premium;
  document.getElementById("analytics-unlocked").hidden = !premium;
  document.getElementById("premium-chip").hidden = !premium;

  const chariowHint = document.getElementById("chariow-hint");
  chariowHint.textContent = CHARIOW_PRODUCT_URL
    ? "Un code s'affiche automatiquement après paiement sur la page Chariow."
    : "";

  if (!premium) return;

  const range = await getStatsRange(7);
  const dayTotals = range.map(({ dayKey, sites }) => {
    const totals = siteTotalsFromDay(sites);
    return { dayKey, totals, sum: sumTotals(totals) };
  });

  const weekSum = dayTotals.reduce(
    (acc, d) => {
      acc.activeSeconds += d.sum.activeSeconds;
      acc.messages += d.sum.messages;
      return acc;
    },
    { activeSeconds: 0, messages: 0 }
  );

  document.getElementById("week-total").textContent = formatDuration(weekSum.activeSeconds);
  document.getElementById("week-avg").textContent = formatDuration(weekSum.activeSeconds / 7);
  document.getElementById("week-per-msg").textContent =
    weekSum.messages > 0 ? formatDuration(weekSum.activeSeconds / weekSum.messages) : "—";

  let best = dayTotals[0];
  for (const d of dayTotals) if (d.sum.activeSeconds > best.sum.activeSeconds) best = d;
  document.getElementById("week-best-day").textContent =
    best.sum.activeSeconds > 0 ? DAY_LABELS[new Date(best.dayKey).getDay()] : "—";

  const chart = document.getElementById("week-chart");
  chart.innerHTML = "";
  const maxSeconds = Math.max(1, ...dayTotals.map((d) => d.sum.activeSeconds));
  const todayStr = todayKey();
  for (const d of dayTotals) {
    const col = document.createElement("div");
    col.className = "chart-col";
    const barHeight = Math.max(2, Math.round((d.sum.activeSeconds / maxSeconds) * 100));
    const isToday = d.dayKey === todayStr;
    col.innerHTML = `
      <div class="chart-bar ${isToday ? "is-today" : ""}" style="height:${barHeight}%"></div>
      <div class="chart-day-label">${DAY_LABELS[new Date(d.dayKey).getDay()]}</div>
    `;
    chart.appendChild(col);
  }

  const weekTotals = {};
  for (const site of SITE_KEYS) {
    weekTotals[site] = dayTotals.reduce(
      (acc, d) => {
        acc.activeSeconds += d.totals[site].activeSeconds;
        acc.messages += d.totals[site].messages;
        return acc;
      },
      { activeSeconds: 0, messages: 0, sessions: 0 }
    );
  }
  renderSiteList(document.getElementById("week-sites"), weekTotals);
}

async function exportData(format) {
  const range = await getStatsRange(90);
  if (format === "json") {
    downloadBlob(JSON.stringify(range, null, 2), "ai-usage-tracker-export.json", "application/json");
    return;
  }
  const rows = [["date", "site", "activeSeconds", "messages", "sessions"]];
  for (const { dayKey, sites } of range) {
    const totals = siteTotalsFromDay(sites);
    for (const site of SITE_KEYS) {
      const t = totals[site];
      rows.push([dayKey, site, t.activeSeconds, t.messages, t.sessions]);
    }
  }
  const csv = rows.map((r) => r.join(",")).join("\n");
  downloadBlob(csv, "ai-usage-tracker-export.csv", "text/csv");
}

function downloadBlob(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

document.getElementById("export-json").addEventListener("click", () => exportData("json"));
document.getElementById("export-csv").addEventListener("click", () => exportData("csv"));

// ---------- Onglet "Réglages" ----------
async function renderSettings() {
  const [settings, premium] = await Promise.all([getSettings(), isPremium()]);

  const goalType = settings.goalType || "none";
  document.querySelectorAll('input[name="goal-type"]').forEach((r) => {
    r.checked = r.value === goalType;
    r.disabled = !premium;
  });
  const minutesInput = document.getElementById("goal-minutes");
  minutesInput.value = settings.goalMinutes || 120;
  minutesInput.disabled = !premium;
  document.getElementById("save-goal").disabled = !premium;
  document.getElementById("goal-premium-hint").textContent = premium
    ? ""
    : "Fonctionnalité premium — débloque-la dans l'onglet Analytics.";

  const toggleList = document.getElementById("widget-toggles");
  toggleList.innerHTML = "";
  for (const site of SITE_KEYS) {
    const info = SITE_INFO[site];
    const row = document.createElement("label");
    row.className = "toggle-row";
    const checked = settings.widgetEnabled?.[site] !== false;
    row.innerHTML = `<input type="checkbox" data-site="${site}" ${checked ? "checked" : ""}/> ${info.label}`;
    toggleList.appendChild(row);
  }
  toggleList.querySelectorAll("input").forEach((input) => {
    input.addEventListener("change", async () => {
      const current = (await getSettings()).widgetEnabled || {};
      current[input.dataset.site] = input.checked;
      await saveSettings({ widgetEnabled: current });
    });
  });

  document.getElementById("settings-premium-active").hidden = !premium;
  document.getElementById("settings-premium-inactive").hidden = premium;
  if (premium && settings.premiumActivatedAt) {
    const d = new Date(settings.premiumActivatedAt);
    document.getElementById("premium-since").textContent = ` depuis le ${d.toLocaleDateString()}`;
  }
}

document.getElementById("save-goal").addEventListener("click", async () => {
  const selected = document.querySelector('input[name="goal-type"]:checked');
  const type = selected && selected.value !== "none" ? selected.value : null;
  const minutes = Math.max(5, parseInt(document.getElementById("goal-minutes").value, 10) || 120);
  await saveSettings({ goalType: type, goalMinutes: minutes });
  renderToday();
});

// ---------- Déblocage premium (2 points d'entrée : Analytics + Réglages) ----------
function wireUnlock(inputId, buttonId, msgId) {
  const btn = document.getElementById(buttonId);
  btn.addEventListener("click", async () => {
    const input = document.getElementById(inputId);
    const msg = document.getElementById(msgId);
    btn.disabled = true;
    msg.textContent = "Vérification…";
    const res = await chrome.runtime.sendMessage({ type: "VALIDATE_PREMIUM_CODE", code: input.value });
    btn.disabled = false;
    msg.textContent = res.message || (res.ok ? "Premium débloqué." : "Code invalide.");
    if (res.ok) {
      input.value = "";
      await Promise.all([renderToday(), renderAnalytics(), renderSettings()]);
    }
  });
}
wireUnlock("premium-code-input", "premium-unlock-btn", "premium-status-msg");
wireUnlock("premium-code-input-2", "premium-unlock-btn-2", "premium-status-msg-2");

// ---------- Rafraîchissement live pendant que le popup est ouvert ----------
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  renderToday();
  const analyticsPanel = document.querySelector('.panel[data-panel="analytics"]');
  if (analyticsPanel.classList.contains("is-active")) renderAnalytics();
});
setInterval(renderToday, 5000);

renderToday();

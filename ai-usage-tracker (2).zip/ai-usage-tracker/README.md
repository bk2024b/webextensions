# AI Usage Tracker

Extension (Manifest V3) qui affiche le temps réellement actif et le nombre
de messages envoyés sur ChatGPT, Claude, Gemini et Perplexity, avec un
widget flottant sur chaque site et un popup pour le détail / l'historique.

## Installer en local (mode développeur)

1. `chrome://extensions` (ou `edge://extensions`)
2. Activer le "Mode développeur"
3. "Charger l'extension non empaquetée" → sélectionner le dossier
   `ai-usage-tracker/` (celui qui contient `manifest.json`)
4. Ouvrir ChatGPT, Claude, Gemini ou Perplexity : le petit pill de suivi
   doit apparaître en bas à droite après quelques secondes.

## Architecture

```
manifest.json
background/background.js     service worker : reçoit les ticks/messages des
                              content scripts, écrit dans chrome.storage.local,
                              gère la purge de l'historique et la validation
                              du code premium
shared/                       code partagé (modules ES) entre background et popup
  constants.js                sites suivis, seuils de temps, helpers de format
  storage.js                  lecture/écriture du modèle de données
  premium.js                  appel à l'API Chariow pour valider un code
content/
  common/                     scripts classiques (pas de modules) partagés
                              entre les 4 sites : constants.js, dom-utils.js,
                              tracker.js (temps actif), widget.js (pill flottant)
  chatgpt/ claude/ gemini/ perplexity/
                              content.js : sélecteurs spécifiques au site pour
                              repérer la zone de saisie et le bouton d'envoi
popup/                        popup.html / popup.css / popup.js (module) :
                              onglets Aujourd'hui / Analytics / Réglages
icons/                        icônes générées (16/32/48/128)
```

## Modèle de données (`chrome.storage.local`, clé `aiUsageTracker`)

```js
{
  stats: {
    "2026-09-29": {
      chatgpt:    { activeSeconds, messages, sessions, firstSessionStart },
      claude:     { ... },
      gemini:     { ... },
      perplexity: { ... }
    },
    // ... jusqu'à 90 jours d'historique
  },
  meta: { lastActiveAt: { chatgpt: <ts>, ... } }, // sert à détecter les nouvelles sessions
  settings: {
    premium: false,
    premiumActivatedAt: null,
    goalType: null,       // null | "max" | "min"
    goalMinutes: 120,
    widgetEnabled: { chatgpt: true, claude: true, gemini: true, perplexity: true }
  }
}
```

## Temps actif : comment c'est mesuré

Un content script (`content/common/tracker.js`) écoute les interactions
(souris, clavier, scroll, clic) et la visibilité de l'onglet. Chaque
seconde où l'onglet est visible **et** où une interaction a eu lieu il y a
moins de 5 minutes est comptée comme active ; sinon le compteur se met en
pause. Toutes les 5 secondes, le delta accumulé est envoyé au background
qui l'écrit dans le stockage (et détecte une nouvelle "session" si plus de
30 minutes se sont écoulées depuis la dernière activité sur ce site).

## Comptage des messages : point d'attention

Chaque `content/<site>/content.js` écoute l'Entrée (sans Shift) sur la
zone de saisie et le clic sur le bouton d'envoi, avec une liste de
sélecteurs candidats (voir le haut de chaque fichier). **Ces sélecteurs
changent régulièrement avec les mises à jour d'interface de ChatGPT,
Claude, Gemini et Perplexity** — c'est le point le plus fragile de
l'extension et probablement ce qu'il faudra ajuster le plus souvent après
un redesign d'un de ces sites (ouvrir les DevTools sur la zone de saisie
et mettre à jour le tableau `COMPOSER_SELECTORS` / `SEND_BUTTON_SELECTORS`
correspondant).

## Premium (Chariow) — à finaliser

Même flux que DoneBell : paiement unique sur Chariow → un code s'affiche →
l'utilisateur le saisit dans l'extension (onglet Analytics ou Réglages) →
`shared/premium.js` appelle l'API Chariow pour le valider.

Il reste à renseigner, dans `shared/premium.js` :
- `CHARIOW_PRODUCT_ID` (l'ID produit "AI Usage Tracker" sur Chariow)
- `CHARIOW_VALIDATE_ENDPOINT` (URL réelle de validation — celle utilisée
  est un placeholder)

Et dans `manifest.json`, `host_permissions` contient déjà un placeholder
`https://api.chariow.com/*` : à ajuster si l'API Chariow est sur un autre
domaine, sinon `fetch()` sera bloqué par le navigateur.

Si tu configures un lien produit Chariow, renseigne aussi
`CHARIOW_PRODUCT_URL` en haut de `popup/popup.js` pour l'afficher dans
l'onglet Analytics.

## Limites connues / compromis assumés

- Pas de compte utilisateur : tout est local (`chrome.storage.local`).
  Désinstaller l'extension ou vider son stockage efface l'historique.
- Les icônes sont générées par script (simple horloge en dégradé), à
  remplacer par une identité visuelle définitive si besoin.
- **ChatGPT** : le badge est incrusté directement dans l'en-tête du site
  (`<header>`, poussé à droite via `margin-left:auto`) plutôt qu'en overlay
  — voir `content/chatgpt/content.js`. Si aucun `<header>` n'est trouvé
  après 8s (redesign plus profond), il retombe automatiquement sur le pill
  flottant classique pour ne jamais disparaître.
- **Claude, Gemini, Perplexity** : toujours en pill flottant (position fixe
  bas-droite) pour l'instant. Le même traitement "incrusté" peut leur être
  appliqué en dupliquant l'approche de `content/chatgpt/content.js` avec les
  bons sélecteurs d'en-tête pour chaque site.

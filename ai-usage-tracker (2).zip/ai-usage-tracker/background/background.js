import { applyTick, applyMessage, getRoot, setRoot, pruneOldDays } from "../shared/storage.js";
import { validatePremiumCode } from "../shared/premium.js";

chrome.runtime.onInstalled.addListener(async () => {
  // Force la création de la structure par défaut dès l'install.
  const root = await getRoot();
  await setRoot(root);
  chrome.alarms.create("daily-prune", { periodInMinutes: 60 * 24 });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "daily-prune") {
    const root = await getRoot();
    await pruneOldDays(root);
    await setRoot(root);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message)
    .then(sendResponse)
    .catch((err) => sendResponse({ ok: false, error: String(err) }));
  return true; // réponse asynchrone
});

async function handleMessage(message) {
  switch (message?.type) {
    case "TICK": {
      const entry = await applyTick({ site: message.site, seconds: message.seconds });
      return { ok: true, entry };
    }
    case "MESSAGE_SENT": {
      const entry = await applyMessage({ site: message.site });
      return { ok: true, entry };
    }
    case "VALIDATE_PREMIUM_CODE": {
      const result = await validatePremiumCode(message.code);
      return result;
    }
    default:
      return { ok: false, error: "Type de message inconnu" };
  }
}

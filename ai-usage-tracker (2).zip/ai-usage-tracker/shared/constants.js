// Constantes partagées entre le background (service worker) et le popup.
// NB : les content scripts ne peuvent pas importer de modules ES, ils ont
// leur propre copie dans content/common/constants.js (valeurs identiques).

export const SITE_INFO = {
  chatgpt: { label: "ChatGPT", color: "#10a37f" },
  claude: { label: "Claude", color: "#da7756" },
  gemini: { label: "Gemini", color: "#4285f4" },
  perplexity: { label: "Perplexity", color: "#20808d" },
};

export const SITE_KEYS = Object.keys(SITE_INFO);

// Une "session" recommence si plus de 30 min se sont écoulées depuis la
// dernière activité détectée sur ce site.
export const SESSION_GAP_MS = 30 * 60 * 1000;

// Le compteur de temps actif se met en pause après 5 min sans interaction
// (voir content/common/tracker.js).
export const INACTIVITY_TIMEOUT_MS = 5 * 60 * 1000;

// Fréquence à laquelle un content script envoie son delta de temps actif
// au background pour persistance.
export const TICK_INTERVAL_MS = 5000;

export const STORAGE_ROOT_KEY = "aiUsageTracker";

// Nombre de jours d'historique conservés (utilisé par l'analytics premium).
export const HISTORY_RETENTION_DAYS = 90;

export function todayKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function formatDuration(totalSeconds) {
  const s = Math.max(0, Math.round(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0) return `${h}h ${String(m).padStart(2, "0")}m`;
  const sec = s % 60;
  if (m > 0) return `${m}m ${String(sec).padStart(2, "0")}s`;
  return `${sec}s`;
}

export function formatTime(ts) {
  if (!ts) return "—";
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

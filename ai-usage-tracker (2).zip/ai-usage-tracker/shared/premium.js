import { saveSettings, getSettings } from "./storage.js";

// ⚠️ À CONFIGURER : mêmes réglages que pour DoneBell.
// Remplace par l'ID produit Chariow de "AI Usage Tracker" et, si l'API
// Chariow exige une clé secrète pour vérifier les paiements, passe-la ici
// (idéalement via un petit proxy côté serveur plutôt qu'en clair dans
// l'extension, exactement comme pour DoneBell).
const CHARIOW_PRODUCT_ID = "REMPLACE_MOI";
const CHARIOW_VALIDATE_ENDPOINT = "https://api.chariow.com/v1/codes/validate"; // placeholder, à confirmer

/**
 * Vérifie un code premium auprès de l'API Chariow.
 * Retourne { ok: boolean, message: string }.
 */
export async function validatePremiumCode(code) {
  const trimmed = (code || "").trim();
  if (!trimmed) return { ok: false, message: "Merci de saisir un code." };

  try {
    const res = await fetch(CHARIOW_VALIDATE_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ product_id: CHARIOW_PRODUCT_ID, code: trimmed }),
    });

    if (!res.ok) {
      return { ok: false, message: "Code invalide ou déjà utilisé." };
    }

    const data = await res.json().catch(() => ({}));
    if (data && data.valid === true) {
      await saveSettings({ premium: true, premiumActivatedAt: Date.now() });
      return { ok: true, message: "Premium débloqué, merci !" };
    }
    return { ok: false, message: "Code invalide ou déjà utilisé." };
  } catch (err) {
    return {
      ok: false,
      message: "Impossible de vérifier le code pour le moment (réseau).",
    };
  }
}

export async function isPremium() {
  const settings = await getSettings();
  return !!settings.premium;
}

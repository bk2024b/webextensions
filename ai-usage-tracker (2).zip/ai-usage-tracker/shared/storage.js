import {
  SITE_KEYS,
  SESSION_GAP_MS,
  STORAGE_ROOT_KEY,
  HISTORY_RETENTION_DAYS,
  todayKey,
} from "./constants.js";

function defaultSiteEntry() {
  return {
    activeSeconds: 0,
    messages: 0,
    sessions: 0,
    firstSessionStart: null,
  };
}

function defaultRoot() {
  return {
    version: 1,
    stats: {},
    meta: {
      lastActiveAt: {}, // site -> timestamp (ms), toutes dates confondues
    },
    settings: {
      premium: false,
      premiumActivatedAt: null,
      goalType: null, // null | "max" | "min"
      goalMinutes: 120,
      widgetEnabled: Object.fromEntries(SITE_KEYS.map((k) => [k, true])),
    },
  };
}

export async function getRoot() {
  const data = await chrome.storage.local.get(STORAGE_ROOT_KEY);
  const root = data[STORAGE_ROOT_KEY];
  if (!root) return defaultRoot();
  // Fusion défensive avec les valeurs par défaut (pour les mises à jour futures).
  const base = defaultRoot();
  return {
    ...base,
    ...root,
    meta: { ...base.meta, ...(root.meta || {}) },
    settings: { ...base.settings, ...(root.settings || {}) },
  };
}

export async function setRoot(root) {
  await chrome.storage.local.set({ [STORAGE_ROOT_KEY]: root });
  return root;
}

function ensureDay(root, dayKey) {
  if (!root.stats[dayKey]) root.stats[dayKey] = {};
  const day = root.stats[dayKey];
  for (const site of SITE_KEYS) {
    if (!day[site]) day[site] = defaultSiteEntry();
  }
  return day;
}

/**
 * Applique un "tick" de temps actif pour un site (appelé toutes les
 * TICK_INTERVAL_MS depuis le content script tant que l'utilisateur est
 * actif). Gère aussi la détection de nouvelle session (écart > 30 min).
 */
export async function applyTick({ site, seconds, now = Date.now() }) {
  if (!SITE_KEYS.includes(site) || !seconds || seconds <= 0) return null;
  const root = await getRoot();
  const dayKey = todayKey(new Date(now));
  const day = ensureDay(root, dayKey);
  const entry = day[site];

  const lastActive = root.meta.lastActiveAt[site] || 0;
  const isNewSession = now - lastActive > SESSION_GAP_MS;
  if (isNewSession || entry.sessions === 0) {
    entry.sessions += 1;
    if (!entry.firstSessionStart) entry.firstSessionStart = now;
  }

  entry.activeSeconds += seconds;
  root.meta.lastActiveAt[site] = now;

  await pruneOldDays(root);
  await setRoot(root);
  return entry;
}

export async function applyMessage({ site, now = Date.now() }) {
  if (!SITE_KEYS.includes(site)) return null;
  const root = await getRoot();
  const dayKey = todayKey(new Date(now));
  const day = ensureDay(root, dayKey);
  day[site].messages += 1;
  await setRoot(root);
  return day[site];
}

export async function getSettings() {
  const root = await getRoot();
  return root.settings;
}

export async function saveSettings(patch) {
  const root = await getRoot();
  root.settings = { ...root.settings, ...patch };
  await setRoot(root);
  return root.settings;
}

export async function getStatsForDate(dayKey) {
  const root = await getRoot();
  return root.stats[dayKey] || null;
}

/** Retourne un tableau [{ dayKey, sites: {...} }] pour les N derniers jours (incl. aujourd'hui), ordre chronologique. */
export async function getStatsRange(days) {
  const root = await getRoot();
  const out = [];
  const now = new Date();
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const key = todayKey(d);
    out.push({ dayKey: key, sites: root.stats[key] || null });
  }
  return out;
}

export async function pruneOldDays(root) {
  const keys = Object.keys(root.stats).sort();
  if (keys.length <= HISTORY_RETENTION_DAYS) return root;
  const toRemove = keys.slice(0, keys.length - HISTORY_RETENTION_DAYS);
  for (const k of toRemove) delete root.stats[k];
  return root;
}

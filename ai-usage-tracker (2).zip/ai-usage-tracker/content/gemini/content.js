(function () {
  const SITE = "gemini";
  const tracker = new AIUTTracker(SITE);
  tracker.start();
  AIUTCreateWidget(SITE);

  // ⚠️ Sélecteurs susceptibles de changer avec les mises à jour de l'UI Gemini.
  const COMPOSER_SELECTORS = [
    "rich-textarea div[contenteditable='true']",
    "div.ql-editor[contenteditable='true']",
    'div[contenteditable="true"]',
  ];
  const SEND_BUTTON_SELECTORS = [
    'button[aria-label="Send message"]',
    'button[aria-label*="Send"]',
  ];

  aiutWaitAndObserve(COMPOSER_SELECTORS, (el) => {
    el.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) tracker.recordMessage();
    });
  });

  aiutWaitAndObserve(SEND_BUTTON_SELECTORS, (btn) => {
    btn.addEventListener("click", () => tracker.recordMessage());
  });
})();

(function () {
  const SITE = "perplexity";
  const tracker = new AIUTTracker(SITE);
  tracker.start();
  AIUTCreateWidget(SITE);

  // ⚠️ Sélecteurs susceptibles de changer avec les mises à jour de l'UI Perplexity.
  const COMPOSER_SELECTORS = [
    'textarea[placeholder]',
    "textarea",
  ];
  const SEND_BUTTON_SELECTORS = [
    'button[aria-label="Submit"]',
    'button[aria-label*="Submit"]',
    'button[aria-label*="Send"]',
  ];

  aiutWaitAndObserve(COMPOSER_SELECTORS, (el) => {
    el.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) tracker.recordMessage();
    });
  });

  aiutWaitAndObserve(SEND_BUTTON_SELECTORS, (btn) => {
    btn.addEventListener("click", () => tracker.recordMessage());
  });
})();

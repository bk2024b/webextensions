(function () {
  const SITE = "chatgpt";
  const tracker = new AIUTTracker(SITE);
  tracker.start();

  // --- Incrustation du compteur dans l'en-tête de ChatGPT --------------
  // ChatGPT est une SPA React : même quand <header> reste le même noeud DOM,
  // React peut effacer/reconstruire ses enfants à chaque re-rendu (nouvelle
  // conversation, ouverture d'un menu, etc.) et emporter notre badge avec.
  // On ne fait donc pas un simple insert "one-shot" : on vérifie
  // régulièrement que le badge est toujours accroché à l'en-tête et on le
  // rattache sinon (heartbeat + MutationObserver en complément).
  //
  // ⚠️ Point le plus fragile du fichier : si le badge n'apparaît plus du
  // tout après une grosse refonte de ChatGPT, c'est probablement que
  // HEADER_SELECTORS ne matche plus rien — à ajuster ici.
  const HEADER_SELECTORS = ["header", 'div[role="banner"]'];
  const FLOATING_FALLBACK_DELAY_MS = 8000;

  let badgeHost = null;
  let usingFloatingFallback = false;
  let stopped = false;
  const startedAt = Date.now();

  function findHeader() {
    for (const sel of HEADER_SELECTORS) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  function applyInlineStyle(el) {
    el.style.position = "";
    el.style.zIndex = "";
    el.style.bottom = "";
    el.style.right = "";
    el.style.marginLeft = "auto";
    el.style.flexShrink = "0";
    el.style.alignSelf = "center";
  }

  function applyFloatingStyle(el) {
    el.style.marginLeft = "";
    el.style.flexShrink = "";
    el.style.alignSelf = "";
    el.style.position = "fixed";
    el.style.zIndex = "2147483647";
    el.style.bottom = "18px";
    el.style.right = "18px";
  }

  async function ensureAttached() {
    if (stopped) return;

    // L'utilisateur a cliqué sur "✕ masquer" : on arrête tout proprement.
    if (sessionStorage.getItem("aiut-widget-hidden") === "1") {
      stopped = true;
      return;
    }

    if (!badgeHost) {
      badgeHost = await AIUTCreateInlineBadge(SITE);
      if (!badgeHost) {
        stopped = true; // désactivé dans les réglages
        return;
      }
    }

    const header = findHeader();

    if (header) {
      if (badgeHost.parentElement !== header) {
        applyInlineStyle(badgeHost);
        header.appendChild(badgeHost);
      }
      usingFloatingFallback = false;
      return;
    }

    // Pas d'en-tête trouvable pour l'instant : au bout de 8s on bascule en
    // pill flottant pour ne jamais perdre le compteur. On continue quand
    // même d'essayer de retrouver un en-tête en arrière-plan ; dès que
    // c'en est trouvé, le badge repasse en mode incrusté (branche ci-dessus).
    if (!usingFloatingFallback && Date.now() - startedAt > FLOATING_FALLBACK_DELAY_MS) {
      applyFloatingStyle(badgeHost);
      document.documentElement.appendChild(badgeHost);
      usingFloatingFallback = true;
    }
  }

  ensureAttached();
  setInterval(ensureAttached, 2500);
  const debouncedEnsure = aiutDebounce(ensureAttached, 500);
  new MutationObserver(debouncedEnsure).observe(document.documentElement, {
    childList: true,
    subtree: true,
  });

  // --- Détection des messages envoyés -----------------------------------
  const COMPOSER_SELECTORS = [
    "#prompt-textarea",
    'textarea[data-testid="prompt-textarea"]',
    "form textarea",
  ];
  const SEND_BUTTON_SELECTORS = [
    'button[data-testid="send-button"]',
    'button[aria-label="Send prompt"]',
    'button[aria-label*="Send"]',
  ];

  aiutWaitAndObserve(COMPOSER_SELECTORS, (el) => {
    el.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) tracker.recordMessage();
    });
  });

  aiutWaitAndObserve(SEND_BUTTON_SELECTORS, (btn) => {
    btn.addEventListener("click", () => tracker.recordMessage());
  });
})();

(function () {
  const SITE = "claude";
  const tracker = new AIUTTracker(SITE);
  tracker.start();
  AIUTCreateWidget(SITE);

  // ⚠️ Sélecteurs susceptibles de changer avec les mises à jour de l'UI Claude.ai.
  const COMPOSER_SELECTORS = [
    'div[contenteditable="true"].ProseMirror',
    'div[enterkeyhint="enter"][contenteditable="true"]',
    'div[contenteditable="true"]',
  ];
  const SEND_BUTTON_SELECTORS = [
    'button[aria-label="Send Message"]',
    'button[aria-label*="Send"]',
  ];

  aiutWaitAndObserve(COMPOSER_SELECTORS, (el) => {
    el.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) tracker.recordMessage();
    });
  });

  aiutWaitAndObserve(SEND_BUTTON_SELECTORS, (btn) => {
    btn.addEventListener("click", () => tracker.recordMessage());
  });
})();

/**
 * Badge de suivi (temps actif + messages du jour) pour le site courant.
 * Rendu en Shadow DOM pour ne pas hériter des styles de la page hôte.
 *
 * Deux variantes possibles, construites sur la même base (AIUTBuildBadge) :
 *  - AIUTCreateWidget(site)       -> pill flottant, position fixe (fallback
 *                                     utilisé quand on ne trouve pas de point
 *                                     d'ancrage dans l'interface du site)
 *  - AIUTCreateInlineBadge(site)  -> badge "nu" à insérer par l'appelant
 *                                     directement dans l'interface du site
 *                                     (ex: l'en-tête de ChatGPT)
 */

async function AIUTIsWidgetEnabled(site) {
  try {
    const data = await chrome.storage.local.get(AIUT_STORAGE_ROOT_KEY);
    const root = data[AIUT_STORAGE_ROOT_KEY];
    const enabled = root && root.settings && root.settings.widgetEnabled;
    return !enabled || enabled[site] !== false; // activé par défaut
  } catch (e) {
    return true;
  }
}

function AIUTBuildBadge(site, { compact = false } = {}) {
  const info = AIUT_SITE_INFO[site] || { label: site, color: "#6366f1" };

  const host = document.createElement("div");
  host.id = "aiut-widget-host";
  host.style.all = "initial";
  host.style.display = "inline-flex";

  const shadow = host.attachShadow({ mode: "open" });
  const style = document.createElement("style");
  style.textContent = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
    .pill {
      display: flex; align-items: center; gap: 7px;
      background: rgba(23, 23, 28, 0.92);
      color: #fff; padding: ${compact ? "5px 10px" : "7px 12px"}; border-radius: 999px;
      font-size: ${compact ? "11.5px" : "12.5px"}; line-height: 1; cursor: default;
      border: 1px solid rgba(255,255,255,0.08);
      ${compact ? "" : "box-shadow: 0 4px 16px rgba(0,0,0,0.28); backdrop-filter: blur(6px);"}
      white-space: nowrap;
    }
    .dot { width: 6px; height: 6px; border-radius: 50%; background: ${info.color}; flex: none; }
    .sep { opacity: 0.35; }
    .close {
      margin-left: 1px; cursor: pointer; opacity: 0.45; font-size: 12px;
      border: none; background: transparent; color: #fff; line-height: 1; padding: 0 1px;
    }
    .close:hover { opacity: 0.9; }
  `;

  const pill = document.createElement("div");
  pill.className = "pill";
  pill.innerHTML = `
    <span class="dot"></span>
    <span class="aiut-time">0s</span>
    <span class="sep">·</span>
    <span class="aiut-msgs">0</span>
    <button class="close" title="Masquer pour cette page">✕</button>
  `;

  shadow.appendChild(style);
  shadow.appendChild(pill);

  pill.querySelector(".close").addEventListener("click", () => {
    sessionStorage.setItem("aiut-widget-hidden", "1");
    host.remove();
  });

  async function refresh() {
    try {
      const data = await chrome.storage.local.get(AIUT_STORAGE_ROOT_KEY);
      const root = data[AIUT_STORAGE_ROOT_KEY];
      const day = root && root.stats && root.stats[aiutTodayKey()];
      const entry = day && day[site];
      pill.querySelector(".aiut-time").textContent = aiutFormatDuration(entry ? entry.activeSeconds : 0);
      pill.querySelector(".aiut-msgs").textContent = `${entry ? entry.messages : 0} msg`;
    } catch (e) {
      /* extension possiblement en cours de rechargement, on réessaiera au prochain tick */
    }
  }

  refresh();
  const interval = setInterval(refresh, 4000);

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[AIUT_STORAGE_ROOT_KEY]) refresh();
    });
  } catch (e) {
    /* no-op */
  }

  window.addEventListener("pagehide", () => clearInterval(interval));

  return { host, pill, refresh };
}

/** Pill flottant, position fixe en bas à droite (fallback). */
async function AIUTCreateWidget(site) {
  if (sessionStorage.getItem("aiut-widget-hidden") === "1") return null;
  if (!(await AIUTIsWidgetEnabled(site))) return null;

  const { host } = AIUTBuildBadge(site, { compact: false });
  host.style.position = "fixed";
  host.style.zIndex = "2147483647";
  host.style.bottom = "18px";
  host.style.right = "18px";
  document.documentElement.appendChild(host);
  return host;
}

/** Badge "nu", à insérer par l'appelant dans l'interface du site (pas de positionnement fixe). */
async function AIUTCreateInlineBadge(site) {
  if (sessionStorage.getItem("aiut-widget-hidden") === "1") return null;
  if (!(await AIUTIsWidgetEnabled(site))) return null;

  const { host } = AIUTBuildBadge(site, { compact: true });
  return host;
}

/**
 * AIUTTracker : mesure le temps "réellement actif" passé sur le site
 * (onglet visible + interaction récente), et signale les messages envoyés.
 *
 * Le temps actif n'est PAS "onglet ouvert" : il se met en pause après
 * AIUT_INACTIVITY_TIMEOUT_MS sans interaction (souris/clavier/scroll/clic)
 * ou dès que l'onglet passe en arrière-plan, et reprend dès qu'une
 * activité est détectée.
 */
class AIUTTracker {
  constructor(site) {
    this.site = site;
    this.lastActivityAt = Date.now();
    this.pendingSeconds = 0;
    this._tickTimer = null;
    this._secondTimer = null;
    this._lastMessageAt = 0;
    this._onActivity = this._onActivity.bind(this);
    this._onVisibility = this._onVisibility.bind(this);
    this._flush = this._flush.bind(this);
  }

  start() {
    ["mousemove", "keydown", "scroll", "click", "wheel", "touchstart"].forEach((evt) =>
      window.addEventListener(evt, this._onActivity, { passive: true })
    );
    document.addEventListener("visibilitychange", this._onVisibility);

    // Accumulation seconde par seconde tant que l'onglet est actif.
    this._secondTimer = setInterval(() => {
      if (this._isActiveNow()) this.pendingSeconds += 1;
    }, 1000);

    // Flush périodique vers le background (persistance + widget).
    this._tickTimer = setInterval(this._flush, AIUT_TICK_INTERVAL_MS);

    // Best-effort flush avant fermeture/navigation.
    window.addEventListener("pagehide", this._flush);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") this._flush();
    });
  }

  _onActivity() {
    this.lastActivityAt = Date.now();
  }

  _onVisibility() {
    if (document.visibilityState === "visible") this.lastActivityAt = Date.now();
  }

  _isActiveNow() {
    if (document.visibilityState !== "visible") return false;
    return Date.now() - this.lastActivityAt < AIUT_INACTIVITY_TIMEOUT_MS;
  }

  _flush() {
    if (this.pendingSeconds <= 0) return;
    const seconds = this.pendingSeconds;
    this.pendingSeconds = 0;
    try {
      chrome.runtime.sendMessage({ type: "TICK", site: this.site, seconds });
    } catch (e) {
      // Le service worker peut être temporairement inactif : la prochaine
      // seconde accumulée sera renvoyée au tick suivant. On ne perd que la
      // dernière tranche en cas d'échec répété (impact négligeable).
    }
  }

  /** À appeler quand un message utilisateur est envoyé sur le site. */
  recordMessage() {
    const now = Date.now();
    if (now - this._lastMessageAt < 500) return; // anti double-comptage (Entrée + clic)
    this._lastMessageAt = now;
    try {
      chrome.runtime.sendMessage({ type: "MESSAGE_SENT", site: this.site });
    } catch (e) {
      /* voir commentaire ci-dessus */
    }
  }
}

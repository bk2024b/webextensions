/**
 * Observe le DOM et appelle onFound(el) chaque fois qu'un élément
 * correspondant à l'un des sélecteurs candidats apparaît (et n'a pas déjà
 * été traité). Utile car ChatGPT/Claude/Gemini/Perplexity sont des SPA qui
 * montent/démontent leur zone de saisie dynamiquement.
 *
 * NB : les sélecteurs CSS de ces sites changent régulièrement avec leurs
 * mises à jour d'interface. Si la détection de messages s'arrête de
 * fonctionner, c'est probablement ici qu'il faut mettre à jour les
 * sélecteurs (voir content/<site>/content.js).
 */
function aiutWaitAndObserve(selectors, onFound) {
  const seen = new WeakSet();

  function scan() {
    for (const sel of selectors) {
      let el;
      try {
        el = document.querySelector(sel);
      } catch (e) {
        continue;
      }
      if (el && !seen.has(el)) {
        seen.add(el);
        onFound(el);
      }
    }
  }

  scan();
  const mo = new MutationObserver(() => scan());
  mo.observe(document.documentElement, { childList: true, subtree: true });
  return mo;
}

/** Petit debounce utilitaire (évite de compter 2x le même envoi de message). */
function aiutDebounce(fn, delay) {
  let last = 0;
  return (...args) => {
    const now = Date.now();
    if (now - last < delay) return;
    last = now;
    fn(...args);
  };
}

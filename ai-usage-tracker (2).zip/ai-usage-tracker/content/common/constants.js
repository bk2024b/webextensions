// Copie "classique" (non-module) des constantes utilisées côté content
// scripts. Doit rester cohérente avec shared/constants.js.
const AIUT_SITE_INFO = {
  chatgpt: { label: "ChatGPT", color: "#10a37f" },
  claude: { label: "Claude", color: "#da7756" },
  gemini: { label: "Gemini", color: "#4285f4" },
  perplexity: { label: "Perplexity", color: "#20808d" },
};

const AIUT_INACTIVITY_TIMEOUT_MS = 5 * 60 * 1000;
const AIUT_TICK_INTERVAL_MS = 5000;
const AIUT_STORAGE_ROOT_KEY = "aiUsageTracker";

function aiutTodayKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function aiutFormatDuration(totalSeconds) {
  const s = Math.max(0, Math.round(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0) return `${h}h ${String(m).padStart(2, "0")}m`;
  const sec = s % 60;
  if (m > 0) return `${m}m ${String(sec).padStart(2, "0")}s`;
  return `${sec}s`;
}

/* YouTube Spaces : isole l'interface YouTube sur les créateurs du space actif. */
(() => {
  'use strict';

  const CARD = [
    'ytd-rich-item-renderer', 'ytd-video-renderer', 'ytd-grid-video-renderer', 'ytd-compact-video-renderer',
    'yt-lockup-view-model', 'ytd-playlist-renderer', 'ytd-compact-playlist-renderer'
  ].join(',');
  const FILTER_PATHS = [/^\/$/, /^\/results/, /^\/watch/, /^\/feed\/(subscriptions|trending|explore)/, /^\/hashtag\//];
  const IDS_KEY = 'yts_ids';
  const FEED_KEY = 'yts_feed';
  const FEED_TTL = 20 * 60 * 1000;

  const root = document.documentElement;
  let state = null;
  let ids = {};   // handle -> channelId (résolu une fois)
  let feed = {};  // channelId -> { t, items }
  let peek = false;
  let timer = 0;
  let autoDone = '';

  const onFilterPath = () => FILTER_PATHS.some(r => r.test(location.pathname));
  const activeSpace = () => (state && state.spaces.find(s => s.id === state.activeId)) || null;
  const setAttr = (name, on) => { if (root.hasAttribute(name) !== on) root.toggleAttribute(name, on); };
  const schedule = () => { if (!timer) timer = setTimeout(() => { timer = 0; apply(); }, 120); };

  /* ---------- Reconnaissance des chaînes ---------- */

  function buildMatcher(sp) {
    const handles = new Set();
    const chIds = new Set();
    for (const c of sp.channels) {
      if (c.handle) { handles.add(c.handle); if (ids[c.handle]) chIds.add(ids[c.handle]); }
      if (c.id) chIds.add(c.id);
    }
    return ref => !!ref && ((ref.handle && handles.has(ref.handle)) || (ref.id && chIds.has(ref.id)));
  }

  function channelRef(card) {
    for (const a of card.querySelectorAll('a[href]')) {
      const r = YTS.parseHref(a.getAttribute('href'));
      if (r) return r;
    }
    return null;
  }

  function durationSec(card) {
    const nodes = card.querySelectorAll('.badge-shape-wiz__text, ytd-thumbnail-overlay-time-status-renderer span, ytd-thumbnail-overlay-time-status-renderer #text');
    for (const n of nodes) {
      const t = n.textContent.trim();
      if (/^\d{1,2}(:\d{2}){1,2}$/.test(t)) return t.split(':').reduce((a, b) => a * 60 + Number(b), 0);
    }
    return null;
  }

  /* ---------- Application des règles ---------- */

  function clearHidden() {
    for (const el of document.querySelectorAll('[data-yts-hide]')) el.removeAttribute('data-yts-hide');
  }

  function apply() {
    if (!state) return;
    const sp = activeSpace();
    const r = sp && sp.rules;
    const scope = !!sp && !peek && onFilterPath();

    setAttr('data-yts-shorts', !!sp && r.hideShorts);
    setAttr('data-yts-endscreen', !!sp && r.hideEndscreen);
    setAttr('data-yts-isolate', scope && r.isolate);
    const home = scope && r.spaceHome && location.pathname === '/';
    setAttr('data-yts-home', home);
    renderPill(sp);

    if (!scope) { clearHidden(); return; }

    const mine = buildMatcher(sp);
    const minSec = (r.minDurationMin || 0) * 60;
    for (const card of document.querySelectorAll(CARD)) {
      if (card.parentElement && card.parentElement.closest(CARD)) continue; // on ne traite que la carte extérieure
      let hide = false;
      if (r.isolate && !mine(channelRef(card))) hide = true;
      else if (r.hideShorts && card.querySelector('a[href^="/shorts/"]')) hide = true;
      else if (minSec) {
        const d = durationSec(card);
        if (d !== null && d < minSec) hide = true;
      }
      if (card.hasAttribute('data-yts-hide') !== hide) card.toggleAttribute('data-yts-hide', hide);
    }

    if (r.noAutoplay && location.pathname === '/watch' && autoDone !== location.search) {
      const t = document.querySelector('.ytp-autonav-toggle-button[aria-checked="true"]');
      if (t) { t.click(); autoDone = location.search; }
    }

    if (home) renderHome(sp);
  }

  /* ---------- Pastille de space ---------- */

  function renderPill(sp) {
    let b = document.getElementById('yts-pill');
    if (!b) {
      b = document.createElement('button');
      b.id = 'yts-pill';
      b.type = 'button';
      b.title = 'Clic : space suivant. Maj+clic : voir tout YouTube un instant.';
      b.addEventListener('click', e => {
        if (e.shiftKey) { peek = !peek; schedule(); } else { YTS.cycle(state).catch(() => {}); }
      });
      document.body.appendChild(b);
    }
    const label = sp ? `${sp.emoji} ${sp.name}${peek ? ' (tout visible)' : ''}` : 'Tout YouTube';
    if (b.textContent !== label) b.textContent = label;
    b.style.setProperty('--yts-h', sp ? sp.hue : 215);
    b.dataset.off = sp ? '' : '1';
  }

  /* ---------- Feed du space (accueil) ---------- */

  function h(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  const rtf = new Intl.RelativeTimeFormat('fr', { numeric: 'auto' });
  const nf = new Intl.NumberFormat('fr', { notation: 'compact' });
  function ago(ts) {
    const s = (ts - Date.now()) / 1000;
    const a = Math.abs(s);
    const [v, u] = a < 3600 ? [s / 60, 'minute'] : a < 86400 ? [s / 3600, 'hour'] : a < 2592000 ? [s / 86400, 'day'] : a < 31536000 ? [s / 2592000, 'month'] : [s / 31536000, 'year'];
    return rtf.format(Math.round(v), u);
  }

  async function resolveId(handle) {
    if (ids[handle]) return ids[handle];
    const res = await fetch('/@' + encodeURIComponent(handle));
    if (!res.ok) throw new Error('chaîne introuvable');
    const html = await res.text();
    const m = html.match(/rel="canonical" href="https:\/\/www\.youtube\.com\/channel\/(UC[\w-]{22})"/)
      || html.match(/"channelId":"(UC[\w-]{22})"/)
      || html.match(/"externalId":"(UC[\w-]{22})"/);
    if (!m) throw new Error('identifiant introuvable');
    ids[handle] = m[1];
    chrome.storage.local.set({ [IDS_KEY]: ids });
    return m[1];
  }

  async function loadChannel(c) {
    const id = c.id || await resolveId(c.handle);
    const hit = feed[id];
    if (hit && Date.now() - hit.t < FEED_TTL) return hit.items;
    const res = await fetch('/feeds/videos.xml?channel_id=' + id);
    if (!res.ok) throw new Error('flux indisponible');
    const doc = new DOMParser().parseFromString(await res.text(), 'text/xml');
    const authorEl = doc.getElementsByTagName('author')[0];
    const author = (authorEl && authorEl.getElementsByTagName('name')[0] ? authorEl.getElementsByTagName('name')[0].textContent : c.name) || '';
    const items = [...doc.getElementsByTagName('entry')].map(e => {
      const t = n => (e.getElementsByTagName(n)[0] || {}).textContent || '';
      const st = e.getElementsByTagName('media:statistics')[0];
      return { id: t('yt:videoId'), title: t('title'), pub: Date.parse(t('published')) || 0, author, views: st ? Number(st.getAttribute('views')) : null };
    }).filter(v => v.id);
    feed[id] = { t: Date.now(), items };
    for (const k of Object.keys(feed)) if (Date.now() - feed[k].t > 3 * 86400000) delete feed[k];
    chrome.storage.local.set({ [FEED_KEY]: feed });
    return items;
  }

  async function pool(list, n, fn) {
    const out = new Array(list.length).fill(null);
    let i = 0;
    await Promise.all(Array.from({ length: Math.min(n, list.length) }, async () => {
      while (i < list.length) {
        const k = i++;
        try { out[k] = await fn(list[k]); } catch (e) { out[k] = null; }
      }
    }));
    return out;
  }

  function homeHead(sp) {
    const w = h('div', 'yts-head');
    const b = h('button', 'yts-refresh', 'Actualiser');
    b.type = 'button';
    b.addEventListener('click', () => {
      for (const c of sp.channels) { const id = c.id || ids[c.handle]; if (id) delete feed[id]; }
      const box = document.getElementById('yts-home');
      if (box) delete box.dataset.token;
      schedule();
    });
    w.append(h('h2', '', `${sp.emoji} ${sp.name}`), b);
    return w;
  }

  function videoCard(v) {
    const a = h('a', 'yts-card');
    a.href = '/watch?v=' + encodeURIComponent(v.id);
    const img = h('img');
    img.loading = 'lazy';
    img.alt = '';
    img.src = `https://i.ytimg.com/vi/${encodeURIComponent(v.id)}/mqdefault.jpg`;
    const meta = [v.author, v.views != null ? nf.format(v.views) + ' vues' : '', ago(v.pub)].filter(Boolean).join(' · ');
    a.append(img, h('div', 'yts-title', v.title), h('div', 'yts-meta', meta));
    return a;
  }

  async function renderHome(sp) {
    const host = document.querySelector('ytd-browse[page-subtype="home"]');
    if (!host) return;
    let box = document.getElementById('yts-home');
    if (!box) { box = h('div'); box.id = 'yts-home'; host.prepend(box); }
    const token = [sp.id, sp.name, sp.emoji, ...sp.channels.map(c => c.id || c.handle)].join('|');
    if (box.dataset.token === token) return;
    box.dataset.token = token;

    if (!sp.channels.length) {
      box.replaceChildren(homeHead(sp), h('p', 'yts-note', 'Ce space est vide. Ouvre une chaîne, puis ajoute-la depuis l’icône de l’extension.'));
      return;
    }
    box.replaceChildren(homeHead(sp), h('p', 'yts-note', 'Chargement des dernières vidéos…'));

    const results = await pool(sp.channels, 4, loadChannel);
    if (box.dataset.token !== token) return; // le space a changé pendant le chargement

    const items = results.filter(Boolean).flat().sort((a, b) => b.pub - a.pub).slice(0, 72);
    const failed = results.filter(r => !r).length;
    const grid = h('div', 'yts-grid');
    grid.append(...items.map(videoCard));
    const nodes = [homeHead(sp)];
    if (failed) nodes.push(h('p', 'yts-note', `${failed} chaîne(s) n’ont pas pu être chargées. Vérifie le @handle dans le popup.`));
    nodes.push(items.length ? grid : h('p', 'yts-note', 'Aucune vidéo trouvée pour ce space.'));
    box.replaceChildren(...nodes);
  }

  /* ---------- Chaîne de la page courante (pour le popup) ---------- */

  function pageChannel() {
    const p = location.pathname;
    let m = p.match(/^\/@([^/]+)/);
    if (m) return { handle: YTS.normHandle(m[1]), name: document.title.replace(/ - YouTube$/, '').replace(/^\(\d+\)\s*/, '').trim() };
    m = p.match(/^\/channel\/(UC[\w-]{22})/);
    if (m) return { id: m[1], name: document.title.replace(/ - YouTube$/, '').replace(/^\(\d+\)\s*/, '').trim() };
    if (p === '/watch') {
      const a = document.querySelector('ytd-watch-metadata ytd-channel-name a[href^="/@"], #owner ytd-channel-name a[href^="/@"]');
      const r = a && YTS.parseHref(a.getAttribute('href'));
      if (r && r.handle) return { handle: r.handle, name: a.textContent.trim() };
    }
    return null;
  }

  chrome.runtime.onMessage.addListener((msg, _sender, send) => {
    if (msg && msg.type === 'getChannel') send(pageChannel());
  });

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch[YTS.KEY]) {
      const prev = state && state.activeId;
      state = ch[YTS.KEY].newValue || state;
      if (state.activeId !== prev) peek = false;
    }
    if (ch[IDS_KEY]) ids = ch[IDS_KEY].newValue || {};
    schedule();
  });

  (async () => {
    const o = await chrome.storage.local.get([IDS_KEY, FEED_KEY]);
    ids = o[IDS_KEY] || {};
    feed = o[FEED_KEY] || {};
    state = await YTS.load();
    new MutationObserver(schedule).observe(root, { childList: true, subtree: true });
    document.addEventListener('yt-navigate-finish', schedule);
    schedule();
  })();
})();

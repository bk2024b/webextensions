importScripts('lib.js');

chrome.runtime.onInstalled.addListener(async () => {
  const o = await chrome.storage.local.get(YTS.KEY);
  if (!o[YTS.KEY]) await YTS.save(YTS.defaults(), { snapshot: false });
});

chrome.commands.onCommand.addListener(async cmd => {
  if (cmd !== 'cycle-space') return;
  await YTS.cycle(await YTS.load());
});

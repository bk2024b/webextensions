/* Données partagées par le popup, le service worker et le script de contenu. */
(function (g) {
  'use strict';

  const KEY = 'yts_state';
  const HUES = [212, 152, 28, 282, 350, 188, 48];
  const RULES = { isolate: true, spaceHome: true, hideShorts: true, hideEndscreen: true, noAutoplay: false, minDurationMin: 0 };
  const SNAP_EVERY = 10 * 60 * 1000;

  const uid = () => 's' + Math.random().toString(36).slice(2, 9);
  const clip = (s, n) => Array.from(String(s)).slice(0, n).join('');
  const normHandle = h => {
    let s = String(h || '');
    try { s = decodeURIComponent(s); } catch (e) { /* garde la valeur brute */ }
    return s.replace(/^@/, '').trim().toLowerCase();
  };

  function newSpace(name, emoji, i) {
    return { id: uid(), name, emoji: emoji || '📁', hue: HUES[(i || 0) % HUES.length], channels: [], rules: { ...RULES } };
  }

  function defaults() {
    return { v: 1, activeId: null, spaces: [newSpace('Apprendre', '🎓', 0), newSpace('Détente', '🍿', 1)], snapshots: [] };
  }

  function normalizeSpace(s, i) {
    return {
      id: s.id || uid(),
      name: clip(s.name || 'Space', 40),
      emoji: clip(s.emoji || '📁', 2),
      hue: Number.isFinite(s.hue) ? s.hue : HUES[i % HUES.length],
      channels: (Array.isArray(s.channels) ? s.channels : [])
        .map(c => ({
          handle: c.handle ? normHandle(c.handle) : '',
          id: /^UC[\w-]{22}$/.test(c.id || '') ? c.id : '',
          name: clip(c.name || c.handle || c.id || '', 80)
        }))
        .filter(c => c.handle || c.id),
      rules: { ...RULES, ...(s.rules || {}) }
    };
  }

  async function load() {
    const o = await chrome.storage.local.get(KEY);
    const st = o[KEY] || defaults();
    if (!Array.isArray(st.snapshots)) st.snapshots = [];
    if (st.activeId && !st.spaces.some(s => s.id === st.activeId)) st.activeId = null;
    return st;
  }

  /* Avant d'écraser l'état, on garde l'ancienne version (une sauvegarde toutes les 10 min, 10 max). */
  async function save(state, { snapshot = true, force = false } = {}) {
    const snaps = Array.isArray(state.snapshots) ? state.snapshots : [];
    if (snapshot) {
      const prev = (await chrome.storage.local.get(KEY))[KEY];
      if (prev && prev.spaces && prev.spaces.length && (force || !snaps[0] || Date.now() - snaps[0].t > SNAP_EVERY)) {
        snaps.unshift({ t: Date.now(), data: { activeId: prev.activeId || null, spaces: prev.spaces } });
      }
    }
    state.snapshots = snaps.slice(0, 10);
    await chrome.storage.local.set({ [KEY]: state });
  }

  async function cycle(state) {
    const order = [null, ...state.spaces.map(s => s.id)];
    const i = Math.max(0, order.indexOf(state.activeId));
    state.activeId = order[(i + 1) % order.length];
    await save(state, { snapshot: false });
  }

  /* Lit un lien de chaîne YouTube (/@handle ou /channel/UC...). */
  function parseHref(href) {
    if (!href) return null;
    let m = href.match(/^(?:https?:\/\/www\.youtube\.com)?\/@([^/?#]+)/);
    if (m) return { handle: normHandle(m[1]) };
    m = href.match(/^(?:https?:\/\/www\.youtube\.com)?\/channel\/(UC[\w-]{22})/);
    if (m) return { id: m[1] };
    return null;
  }

  function handleFromInput(text) {
    const t = String(text || '').trim();
    const m = t.match(/@([^\s/?#]+)/);
    const h = normHandle(m ? m[1] : t);
    return /^[^\s/?#@]{1,60}$/u.test(h) ? h : '';
  }

  const exportJSON = state => JSON.stringify({ v: 1, activeId: state.activeId, spaces: state.spaces }, null, 2);

  function parseImport(text) {
    const d = JSON.parse(text);
    if (!d || !Array.isArray(d.spaces)) throw new Error('fichier invalide');
    return { activeId: d.activeId || null, spaces: d.spaces.map(normalizeSpace) };
  }

  g.YTS = { KEY, newSpace, defaults, load, save, cycle, parseHref, handleFromInput, normHandle, exportJSON, parseImport };
})(globalThis);

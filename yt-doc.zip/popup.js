(async () => {
  'use strict';
  const $ = s => document.querySelector(s);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  let state = await YTS.load();
  let page = null;
  let confirmDel = false;
  const cur = () => state.spaces.find(s => s.id === state.activeId) || null;
  const say = t => { $('#msg').textContent = t; };

  async function getPage() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !/^https:\/\/www\.youtube\.com\//.test(tab.url || '')) return null;
      return await chrome.tabs.sendMessage(tab.id, { type: 'getChannel' });
    } catch (e) { return null; }
  }

  async function commit(opts) { await YTS.save(state, opts); render(); }

  function addChannel(sp, c) {
    if (sp.channels.some(x => (c.handle && x.handle === c.handle) || (c.id && x.id === c.id))) return;
    sp.channels.push({ handle: c.handle || '', id: c.id || '', name: c.name || c.handle || c.id });
  }

  const chip = (id, emoji, name) =>
    `<button class="chip${state.activeId === id ? ' on' : ''}" data-act="tab" data-id="${id || ''}">${esc(emoji)} ${esc(name)}</button>`;

  function spacePanel(sp) {
    const r = sp.rules;
    const list = sp.channels.map((c, i) => {
      const n = c.name || c.handle;
      return `<li><span class="nm">${esc(n)}</span><span class="hd">${c.handle ? '@' + esc(c.handle) : ''}</span>` +
        `<button class="x" data-act="rm" data-i="${i}" aria-label="Retirer ${esc(n)}">×</button></li>`;
    }).join('');
    const known = page && sp.channels.some(c => (page.handle && c.handle === page.handle) || (page.id && c.id === page.id));
    const addPage = page
      ? (known ? `<p class="hint">${esc(page.name || page.handle)} est déjà dans ce space.</p>`
               : `<button class="primary" data-act="add-page">Ajouter ${esc(page.name || page.handle)}</button>`)
      : `<p class="hint">Ouvre une chaîne ou une vidéo sur YouTube pour l’ajouter ici.</p>`;
    const chk = (k, label) => `<label class="chk"><input type="checkbox" data-rule="${k}" ${r[k] ? 'checked' : ''}> <span>${label}</span></label>`;
    return `
      <section class="sec"><div class="row">
        <input class="emo" data-f="emoji" value="${esc(sp.emoji)}" maxlength="4" aria-label="Icône du space">
        <input class="nme" data-f="name" value="${esc(sp.name)}" maxlength="40" aria-label="Nom du space">
      </div></section>
      <section class="sec"><h3>Créateurs (${sp.channels.length})</h3>
        <ul class="chs">${list || '<li class="hint">Aucun créateur pour l’instant.</li>'}</ul>
        ${addPage}
        <div class="row"><input id="handle" placeholder="@handle ou lien de chaîne"><button data-act="add-handle">Ajouter</button></div>
      </section>
      <section class="sec"><h3>Règles de ce space</h3>
        ${chk('isolate', 'Isoler l’interface : accueil, recherche et recommandations ne montrent que ces créateurs')}
        ${chk('spaceHome', 'Remplacer l’accueil par le feed du space')}
        ${chk('hideShorts', 'Masquer les Shorts')}
        ${chk('hideEndscreen', 'Masquer les recommandations de fin de vidéo')}
        ${chk('noAutoplay', 'Couper la lecture automatique')}
        <label class="chk dur">Durée minimale <input type="number" min="0" max="180" data-rule="minDurationMin" value="${Number(r.minDurationMin) || 0}"> min</label>
      </section>
      <section class="sec"><button class="danger" data-act="del">Supprimer ce space</button></section>`;
  }

  function render() {
    const sp = cur();
    document.documentElement.style.setProperty('--h', sp ? sp.hue : 212);
    $('#tabs').innerHTML = chip(null, '🌐', 'Tout YouTube') + state.spaces.map(s => chip(s.id, s.emoji, s.name)).join('') +
      '<button class="chip add" data-act="new" aria-label="Nouveau space" title="Nouveau space">+</button>';
    $('#panel').innerHTML = sp ? spacePanel(sp)
      : '<p class="empty">Aucun space actif : YouTube s’affiche normalement. Choisis un space pour isoler l’interface sur ses créateurs.</p>';
    $('#snaps').innerHTML = state.snapshots.map((s, i) => `<option value="${i}">${esc(new Date(s.t).toLocaleString('fr'))}</option>`).join('') ||
      '<option value="">Aucune sauvegarde</option>';
  }

  document.addEventListener('click', async e => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const sp = cur();
    const act = b.dataset.act;
    say('');
    if (act === 'tab') { state.activeId = b.dataset.id || null; confirmDel = false; await commit({ snapshot: false }); }
    else if (act === 'new') { const s = YTS.newSpace('Nouveau space', '✨', state.spaces.length); state.spaces.push(s); state.activeId = s.id; await commit(); }
    else if (act === 'add-page' && sp && page) { addChannel(sp, page); await commit(); }
    else if (act === 'add-handle' && sp) {
      const hdl = YTS.handleFromInput($('#handle').value);
      if (!hdl) return say('Saisis un @handle ou colle un lien de chaîne.');
      addChannel(sp, { handle: hdl, name: hdl });
      await commit();
    }
    else if (act === 'rm' && sp) { sp.channels.splice(Number(b.dataset.i), 1); await commit(); }
    else if (act === 'del' && sp) {
      if (!confirmDel) { confirmDel = true; b.textContent = 'Confirmer la suppression'; return; }
      state.spaces = state.spaces.filter(s => s !== sp);
      state.activeId = null;
      confirmDel = false;
      await commit({ force: true });
    }
    else if (act === 'export') {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([YTS.exportJSON(state)], { type: 'application/json' }));
      a.download = 'yt-spaces-sauvegarde.json';
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      say('Sauvegarde exportée.');
    }
    else if (act === 'import') $('#file').click();
    else if (act === 'restore') {
      const snap = state.snapshots[Number($('#snaps').value)];
      if (!snap) return say('Aucune sauvegarde à restaurer.');
      state.spaces = JSON.parse(JSON.stringify(snap.data.spaces));
      state.activeId = snap.data.activeId;
      await commit({ force: true });
      say('Sauvegarde restaurée.');
    }
  });

  document.addEventListener('change', async e => {
    const t = e.target;
    const sp = cur();
    if (t.id === 'file') {
      const f = t.files[0];
      if (!f) return;
      try {
        const d = YTS.parseImport(await f.text());
        state.spaces = d.spaces;
        state.activeId = d.activeId;
        await commit({ force: true });
        say('Sauvegarde importée.');
      } catch (err) { say('Import impossible : ' + err.message + '.'); }
      t.value = '';
    } else if (sp && t.dataset.f) {
      sp[t.dataset.f] = t.value.trim() || sp[t.dataset.f];
      await commit();
    } else if (sp && t.dataset.rule) {
      sp.rules[t.dataset.rule] = t.type === 'checkbox' ? t.checked : Math.max(0, Math.min(180, Number(t.value) || 0));
      await commit();
    }
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.target.id === 'handle') document.querySelector('[data-act="add-handle"]').click();
  });

  page = await getPage();
  render();
})();

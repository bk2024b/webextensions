const root = document.getElementById("root");
let data = { stats: {}, session: null };

YTS.load().then((d) => {
  data = d;
  YTS.renderPanel(root, data);
});

chrome.storage.onChanged.addListener((c, area) => {
  if (area !== "local" || !(c.stats || c.session)) return;
  data = {
    stats: c.stats ? c.stats.newValue || {} : data.stats,
    session: c.session ? c.session.newValue : data.session,
  };
  YTS.renderPanel(root, data);
});

// Utilitaires + rendu du panneau, partagés entre la page YouTube et le popup.
const YTS = (() => {
  const pad = (n) => String(n).padStart(2, "0");
  const dayKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const SESSION_GAP = 30 * 60 * 1000;

  const fmt = (s) => {
    s = Math.max(0, Math.round(s));
    if (s < 60) return `${s} s`;
    const m = Math.floor(s / 60);
    if (m < 60) return `${m} min`;
    const h = Math.floor(m / 60);
    const r = m % 60;
    return r ? `${h} h ${pad(r)} min` : `${h} h`;
  };

  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  };

  const icon = (size = 24) => {
    const ns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("width", size);
    svg.setAttribute("height", size);
    svg.setAttribute("fill", "currentColor");
    svg.setAttribute("focusable", "false");
    const p = document.createElementNS(ns, "path");
    p.setAttribute(
      "d",
      "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"
    );
    svg.appendChild(p);
    return svg;
  };

  const load = async () => {
    const { stats = {}, session = null } = await chrome.storage.local.get(["stats", "session"]);
    return { stats, session };
  };

  const summary = ({ stats, session }) => {
    const now = new Date();
    const today = stats[dayKey(now)] || { total: 0, watch: 0 };
    const week = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
      const v = stats[dayKey(d)];
      week.push({ date: d, total: v ? v.total : 0, today: i === 0 });
    }
    const weekTotal = week.reduce((a, b) => a + b.total, 0);
    const live = session && Date.now() - session.last < SESSION_GAP ? session.seconds : 0;
    return { today, week, weekTotal, avg: weekTotal / 7, session: live };
  };

  const build = (root) => {
    root.replaceChildren();
    const panel = el("div", "yts-panel");

    const title = el("div", "yts-title", "Temps réel sur YouTube");
    const sub = el("div", "yts-sub", "Aujourd’hui");
    const big = el("div", "yts-big");

    const split = el("div", "yts-split");
    const splitWatch = el("span");
    split.appendChild(splitWatch);

    const legendItem = (dotCls, label) => {
      const node = el("div", "yts-lg");
      node.append(el("i", "yts-lg-dot " + dotCls), el("span", "", label));
      const val = el("b");
      node.appendChild(val);
      return { node, val };
    };
    const legend = el("div", "yts-legend");
    const lgWatch = legendItem("yts-lg-watch", "Lecture vidéo");
    const lgBrowse = legendItem("yts-lg-browse", "Navigation");
    legend.append(lgWatch.node, lgBrowse.node);

    const cell = (label) => {
      const node = el("div", "yts-cell");
      const val = el("div", "yts-cell-val");
      node.append(el("div", "yts-cell-lab", label), val);
      return { node, val };
    };
    const grid = el("div", "yts-grid");
    const cSession = cell("Session");
    const cAvg = cell("Moy. / jour");
    const cWeek = cell("7 derniers jours");
    grid.append(cSession.node, cAvg.node, cWeek.node);

    const chart = el("div", "yts-chart");
    const cols = [];
    for (let i = 0; i < 7; i++) {
      const col = el("div", "yts-col");
      const bar = el("div", "yts-bar");
      const lab = el("div", "yts-col-lab");
      col.append(bar, lab);
      chart.appendChild(col);
      cols.push({ col, bar, lab });
    }

    const foot = el(
      "div",
      "yts-foot",
      "Compté uniquement quand l’onglet est visible et que vous êtes actif ou qu’une vidéo est en lecture."
    );

    panel.append(
      title, sub, big, split, legend,
      el("div", "yts-sep"), grid,
      el("div", "yts-sep"), chart,
      foot
    );
    root.appendChild(panel);

    return (data) => {
      const s = summary(data);
      big.textContent = fmt(s.today.total);
      const pct = s.today.total ? (s.today.watch / s.today.total) * 100 : 0;
      splitWatch.style.width = pct + "%";
      lgWatch.val.textContent = fmt(s.today.watch);
      lgBrowse.val.textContent = fmt(s.today.total - s.today.watch);
      cSession.val.textContent = fmt(s.session);
      cAvg.val.textContent = fmt(s.avg);
      cWeek.val.textContent = fmt(s.weekTotal);

      const max = Math.max(1, ...s.week.map((d) => d.total));
      s.week.forEach((d, i) => {
        const c = cols[i];
        c.bar.style.height = (d.total ? Math.max(4, Math.round((d.total / max) * 56)) : 2) + "px";
        c.bar.classList.toggle("yts-bar-today", d.today);
        c.lab.textContent = d.date.toLocaleDateString("fr-FR", { weekday: "narrow" });
        c.lab.classList.toggle("yts-col-lab-today", d.today);
        c.col.title =
          d.date.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" }) +
          " : " + fmt(d.total);
      });
    };
  };

  const renderPanel = (root, data) => {
    if (!root._yts) root._yts = build(root);
    root._yts(data);
  };

  return { el, icon, fmt, load, summary, renderPanel };
})();

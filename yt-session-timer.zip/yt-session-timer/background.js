// Agrège les "ticks" envoyés par les onglets YouTube.
// Un seul tick compté par seconde, même si plusieurs onglets sont actifs.
const SESSION_GAP = 30 * 60 * 1000; // une pause > 30 min = nouvelle session
const KEEP_DAYS = 120;

let last = 0;
let queue = Promise.resolve();

const pad = (n) => String(n).padStart(2, "0");
const dayKey = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};

async function record(watching, now) {
  const { stats = {}, session = null } = await chrome.storage.local.get(["stats", "session"]);
  const key = dayKey(now);

  if (!stats[key]) {
    stats[key] = { total: 0, watch: 0 };
    const limit = now - KEEP_DAYS * 86400000;
    for (const k of Object.keys(stats)) {
      if (new Date(k + "T00:00:00").getTime() < limit) delete stats[k];
    }
  }
  stats[key].total += 1;
  if (watching) stats[key].watch += 1;

  let s = session;
  if (!s || now - s.last > SESSION_GAP) s = { start: now, seconds: 0, last: now };
  s.seconds += 1;
  s.last = now;

  await chrome.storage.local.set({ stats, session: s });
}

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.type !== "tick") return;
  const now = Date.now();
  if (now - last < 900) return;
  last = now;
  queue = queue.then(() => record(!!msg.watching, now)).catch(() => {});
});

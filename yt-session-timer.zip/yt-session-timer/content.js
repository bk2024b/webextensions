(() => {
  if (window.top !== window || window.__ytsLoaded) return;
  window.__ytsLoaded = true;

  const { el, icon, fmt, load, summary, renderPanel } = YTS;
  const IDLE_MS = 2 * 60 * 1000; // inactif au-delà de 2 min (hors lecture vidéo)

  let lastActivity = Date.now();
  let open = false;
  let data = { stats: {}, session: null };

  const bump = () => (lastActivity = Date.now());
  for (const ev of ["mousemove", "keydown", "wheel", "click", "touchstart"]) {
    window.addEventListener(ev, bump, { passive: true, capture: true });
  }

  /* ---------- UI ---------- */
  const host = el("div", "yts-host yts-scope");
  const pill = el("button", "yts-pill");
  pill.type = "button";
  pill.setAttribute("aria-label", "Temps réel passé sur YouTube");
  pill.setAttribute("aria-expanded", "false");

  const ico = el("span", "yts-ico");
  ico.append(icon(24), el("i", "yts-dot"));
  const label = el("span", "yts-label", "0 s");
  pill.append(ico, label);

  const dropdown = el("div", "yts-dropdown");
  host.append(pill, dropdown);

  const paint = () => {
    label.textContent = fmt(summary(data).today.total);
    if (open) renderPanel(dropdown, data);
  };

  const setOpen = (v) => {
    open = v;
    host.classList.toggle("yts-open", v);
    pill.setAttribute("aria-expanded", String(v));
    if (v) renderPanel(dropdown, data);
  };

  pill.addEventListener("click", (e) => {
    e.stopPropagation();
    setOpen(!open);
  });
  document.addEventListener("click", (e) => {
    if (open && !host.contains(e.target)) setOpen(false);
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && open) setOpen(false);
  });

  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== "local" || !(c.stats || c.session)) return;
    data = {
      stats: c.stats ? c.stats.newValue || {} : data.stats,
      session: c.session ? c.session.newValue : data.session,
    };
    paint();
  });

  /* ---------- Injection dans la barre YouTube ---------- */
  const mount = () => {
    const end = document.querySelector("ytd-masthead #end");
    if (!end || host.parentElement === end) return;
    end.insertBefore(host, end.querySelector("#buttons") || end.firstChild);
  };

  /* ---------- Suivi du temps ---------- */
  const isWatchPage = () => /^\/(watch|shorts|live)/.test(location.pathname);
  const alive = () => {
    try { return !!chrome.runtime.id; } catch { return false; }
  };

  const tick = () => {
    if (!alive()) {
      clearInterval(timer);
      host.remove();
      return;
    }
    mount();

    const video = document.querySelector("video.html5-main-video") || document.querySelector("video");
    const playing =
      isWatchPage() && !!video && !video.paused && !video.ended && video.readyState > 2;
    const visible = document.visibilityState === "visible";
    const engaged = document.hasFocus() && Date.now() - lastActivity < IDLE_MS;
    const live = visible && (playing || engaged);

    host.classList.toggle("yts-live", live);
    if (live) {
      try { chrome.runtime.sendMessage({ type: "tick", watching: playing }).catch(() => {}); } catch {}
    }
  };

  const timer = setInterval(tick, 1000);
  load().then((d) => { data = d; paint(); }).catch(() => {});
  tick();
})();

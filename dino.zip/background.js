// Un clic sur l'icône ouvre le jeu dans un onglet (100 % local, fonctionne hors-ligne).
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL("game.html") });
});

const cv = document.getElementById("c"), ctx = cv.getContext("2d");
const W = 900, H = 300, GY = 240, DX = 70;
const ACCENT = "#FF6B35";
const PAL = { // [jour, nuit]
  bg: ["#F7F7F5", "#14161A"], ink: ["#2B2E34", "#E8E8E4"],
  near: ["#E9E9E4", "#1E2127"], far: ["#EFEFEA", "#191C21"],
};
const rnd = (a, b) => a + Math.random() * (b - a);
const mix = (a, b, t) => {
  const p = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
  const x = p(a), y = p(b);
  return "rgb(" + x.map((v, i) => Math.round(v + (y[i] - v) * t)).join() + ")";
};
const col = (k, n) => mix(PAL[k][0], PAL[k][1], n);

let best = 0;
try { best = +localStorage.getItem("dino-best") || 0; } catch {}

const s = {};
function reset() {
  Object.assign(s, {
    state: "idle", t: 0, score: 0, speed: 6, dist: 0, gap: 400, shake: 0, flash: 0,
    dy: 0, vy: 0, duck: false, air: false, holdJump: false,
    obs: [], dust: [], deadAt: 0,
    clouds: Array.from({ length: 4 }, () => ({ x: rnd(0, W), y: rnd(30, 110), w: rnd(50, 90) })),
    stars: Array.from({ length: 40 }, () => ({ x: rnd(0, W), y: rnd(10, 150), r: rnd(0.6, 1.6), p: rnd(0, 6) })),
  });
}
reset();

function fit() {
  const dpr = window.devicePixelRatio || 1, w = Math.min(innerWidth, 1000), k = w / W;
  cv.style.width = w + "px"; cv.style.height = H * k + "px";
  cv.width = W * k * dpr; cv.height = H * k * dpr;
  ctx.setTransform(k * dpr, 0, 0, k * dpr, 0, 0);
}
addEventListener("resize", fit); fit();

// ---------- Entrées ----------
function jump() {
  if (s.state === "idle") s.state = "run";
  else if (s.state === "dead") {
    if (performance.now() - s.deadAt > 350) { reset(); s.state = "run"; } else return;
  }
  if (!s.air) { s.vy = -13.5; s.air = true; s.holdJump = true; }
}
addEventListener("keydown", e => {
  if (["Space", "ArrowUp", "KeyW"].includes(e.code)) { e.preventDefault(); if (!e.repeat) jump(); }
  if (e.code === "ArrowDown" || e.code === "KeyS") { e.preventDefault(); s.duck = true; }
});
addEventListener("keyup", e => {
  if (["Space", "ArrowUp", "KeyW"].includes(e.code)) s.holdJump = false;
  if (e.code === "ArrowDown" || e.code === "KeyS") s.duck = false;
});
cv.addEventListener("pointerdown", e => { e.preventDefault(); jump(); });
cv.addEventListener("pointerup", () => { s.holdJump = false; });

// ---------- Logique ----------
function hitbox() {
  return s.duck && !s.air
    ? { x: DX + 4, y: GY - s.dy - 28, w: 42, h: 26 }
    : { x: DX + 6, y: GY - s.dy - 46, w: 32, h: 44 };
}
function spawn() {
  const r = Math.random(), bird = s.score > 300 && r < 0.3;
  let o;
  if (bird) {
    const mid = Math.random() < 0.5;
    o = { type: "bird", w: 44, h: 26, y: GY - (mid ? 62 : 32) };
  } else if (r < 0.65) o = { type: "rock", w: rnd(28, 40), h: rnd(30, 42), y: 0 };
  else o = { type: "crystal", w: 50, h: 46, y: 0 };
  o.x = W + 20; if (o.type !== "bird") o.y = GY - o.h;
  s.obs.push(o);
  s.gap = rnd(280, 480) + s.speed * 22;
}
function die() {
  s.state = "dead"; s.shake = 14; s.flash = 1; s.deadAt = performance.now();
  if (s.score > best) {
    best = Math.floor(s.score);
    try { localStorage.setItem("dino-best", best); } catch {}
  }
}
function update(k) {
  s.t += k;
  if (s.shake > 0) s.shake -= k;
  if (s.flash > 0) s.flash = Math.max(0, s.flash - 0.06 * k);
  if (s.state !== "run") return;

  s.score += s.speed * k * 0.1;
  s.speed = Math.min(6 + s.score * 0.004, 14);
  s.dist += s.speed * k;

  if (s.air) {
    if (!s.holdJump && s.vy < -5) s.vy = -5;           // saut modulable
    s.vy += (s.duck ? 2 : 0.7) * k;                      // chute rapide en se baissant
    s.dy -= s.vy * k;
    if (s.dy <= 0) {
      s.dy = 0; s.vy = 0; s.air = false;
      for (let i = 0; i < 6; i++) s.dust.push({ x: DX + 20, y: GY, vx: rnd(-2, 1), vy: rnd(-2, -0.5), l: 1 });
    }
  }
  s.gap -= s.speed * k; if (s.gap <= 0) spawn();
  s.obs.forEach(o => o.x -= s.speed * k);
  s.obs = s.obs.filter(o => o.x + o.w > -20);
  s.dust.forEach(d => { d.x += d.vx * k; d.y += d.vy * k; d.vy += 0.15 * k; d.l -= 0.04 * k; });
  s.dust = s.dust.filter(d => d.l > 0);
  s.clouds.forEach(c => { c.x -= s.speed * 0.15 * k; if (c.x + c.w < 0) { c.x = W + 20; c.y = rnd(30, 110); } });

  const h = hitbox();
  for (const o of s.obs) {
    const m = 5;
    if (h.x < o.x + o.w - m && h.x + h.w > o.x + m && h.y < o.y + o.h - m && h.y + h.h > o.y + m) { die(); break; }
  }
}

// ---------- Rendu ----------
function roundRect(x, y, w, h, r) { ctx.beginPath(); ctx.roundRect(x, y, w, h, r); ctx.fill(); }

function drawDino(n) {
  const ink = col("ink", n), bg = col("bg", n), duck = s.duck && !s.air;
  ctx.save(); ctx.translate(DX, GY - s.dy); ctx.fillStyle = ink;
  const step = s.state === "run" && !s.air ? Math.floor(s.t / 5) % 2 : 0;
  // jambes
  const ly = duck ? -10 : -14;
  roundRect(8, ly, 7, -ly - (step ? 5 : 0), 3); roundRect(24, ly, 7, -ly - (step ? 0 : 5), 3);
  if (duck) {
    roundRect(-4, -26, 46, 20, 10);               // corps allongé
    roundRect(30, -32, 22, 16, 8);                // tête
    ctx.beginPath(); ctx.moveTo(-4, -20); ctx.lineTo(-18, -12); ctx.lineTo(-4, -10); ctx.fill();
    ctx.fillStyle = bg; ctx.beginPath(); ctx.arc(44, -25, 2.6, 0, 7); ctx.fill();
  } else {
    roundRect(0, -36, 34, 26, 12);                // corps
    roundRect(16, -52, 28, 22, 10);               // tête
    ctx.beginPath(); ctx.moveTo(2, -30); ctx.lineTo(-16, -14); ctx.lineTo(4, -18); ctx.fill(); // queue
    const blink = s.t % 220 < 6;
    ctx.fillStyle = bg;
    if (blink) ctx.fillRect(34, -42, 6, 2); else { ctx.beginPath(); ctx.arc(37, -42, 3, 0, 7); ctx.fill(); }
  }
  ctx.restore();
}

function drawObs(o, n) {
  ctx.save(); ctx.translate(o.x, o.y);
  if (o.type === "rock") {
    ctx.fillStyle = col("ink", n);
    ctx.beginPath(); ctx.roundRect(0, o.h * 0.25, o.w, o.h * 0.75, [o.w * 0.5, o.w * 0.5, 4, 4]); ctx.fill();
  } else if (o.type === "crystal") {
    ctx.fillStyle = ACCENT;
    [[0, 30, 14], [14, 46, 16], [32, 34, 14]].forEach(([x, h, w]) => {
      ctx.beginPath(); ctx.moveTo(x, o.h); ctx.lineTo(x + w / 2, o.h - h); ctx.lineTo(x + w, o.h); ctx.fill();
    });
  } else {
    const up = Math.floor(s.t / 8) % 2;
    ctx.fillStyle = ACCENT;
    ctx.beginPath(); ctx.ellipse(22, 14, 18, 8, 0, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.moveTo(10, 12); ctx.lineTo(24, up ? -2 : 28); ctx.lineTo(30, 12); ctx.fill();
    ctx.beginPath(); ctx.moveTo(4, 14); ctx.lineTo(-4, 12); ctx.lineTo(4, 10); ctx.fill();
  }
  ctx.restore();
}

function draw() {
  // jour/nuit : 0 = jour, 1 = nuit (cycle de ~1200 points)
  const n = (1 - Math.cos(s.score / 1200 * Math.PI * 2)) / 2;
  const bg = col("bg", n), ink = col("ink", n);
  document.body.style.background = bg;

  ctx.save();
  if (s.shake > 0) ctx.translate(rnd(-1, 1) * s.shake * 0.5, rnd(-1, 1) * s.shake * 0.5);
  ctx.fillStyle = bg; ctx.fillRect(-20, -20, W + 40, H + 40);

  // étoiles, soleil/lune
  ctx.fillStyle = "#fff";
  if (n > 0.3) s.stars.forEach(t => {
    ctx.globalAlpha = (n - 0.3) * (0.5 + 0.5 * Math.sin(s.t / 30 + t.p));
    ctx.beginPath(); ctx.arc(t.x, t.y, t.r, 0, 7); ctx.fill();
  });
  ctx.globalAlpha = 1;
  ctx.fillStyle = mix(ACCENT, "#E8E8E4", n); ctx.globalAlpha = 0.9;
  ctx.beginPath(); ctx.arc(760, 70, 20, 0, 7); ctx.fill(); ctx.globalAlpha = 1;

  // nuages
  ctx.fillStyle = col("far", n);
  s.clouds.forEach(c => roundRect(c.x, c.y, c.w, 14, 7));

  // collines parallaxe (2 couches)
  [["far", 0.12, 70, 120], ["near", 0.3, 40, 80]].forEach(([k, sp, amp, per]) => {
    ctx.fillStyle = col(k, n); ctx.beginPath(); ctx.moveTo(0, GY);
    for (let x = 0; x <= W; x += 10) ctx.lineTo(x, GY - 20 - amp * 0.5 - amp * 0.5 * Math.sin((x + s.dist * sp) / per * 2));
    ctx.lineTo(W, GY); ctx.fill();
  });

  // sol
  ctx.fillStyle = ink; ctx.globalAlpha = 0.85; ctx.fillRect(0, GY, W, 2);
  ctx.globalAlpha = 0.35;
  for (let i = 0; i < 30; i++) {
    const x = ((i * 97 - s.dist) % (W + 60) + W + 60) % (W + 60) - 30;
    ctx.fillRect(x, GY + 10 + (i % 4) * 8, 6 + (i % 3) * 6, 2);
  }
  ctx.globalAlpha = 1;

  s.obs.forEach(o => drawObs(o, n));
  s.dust.forEach(d => { ctx.globalAlpha = d.l * 0.5; ctx.fillStyle = ink; ctx.beginPath(); ctx.arc(d.x, d.y, 2.5, 0, 7); ctx.fill(); });
  ctx.globalAlpha = 1;
  drawDino(n);
  ctx.restore();

  // HUD
  ctx.textAlign = "right"; ctx.fillStyle = ink;
  ctx.font = "700 28px ui-monospace, 'SF Mono', Consolas, monospace";
  ctx.fillText(String(Math.floor(s.score)).padStart(5, "0"), W - 24, 44);
  ctx.globalAlpha = 0.5; ctx.font = "500 14px ui-monospace, Consolas, monospace";
  ctx.fillText("MEILLEUR " + String(best).padStart(5, "0"), W - 24, 66); ctx.globalAlpha = 1;

  ctx.textAlign = "left";
  if (!navigator.onLine) {
    ctx.fillStyle = ACCENT; ctx.beginPath(); ctx.arc(30, 36, 5, 0, 7); ctx.fill();
    ctx.fillStyle = ink; ctx.font = "500 15px ui-sans-serif, system-ui, sans-serif"; ctx.fillText("Hors-ligne", 44, 41);
  }

  ctx.textAlign = "center"; ctx.fillStyle = ink;
  if (s.state === "idle") {
    ctx.font = "600 20px ui-sans-serif, system-ui, sans-serif"; ctx.fillText("Espace ou ↑ pour sauter", W / 2, 120);
    ctx.globalAlpha = 0.6; ctx.font = "400 15px ui-sans-serif, system-ui, sans-serif"; ctx.fillText("↓ pour se baisser", W / 2, 148); ctx.globalAlpha = 1;
  } else if (s.state === "dead") {
    ctx.font = "700 34px ui-sans-serif, system-ui, sans-serif"; ctx.fillText("Partie terminée", W / 2, 110);
    ctx.globalAlpha = 0.65; ctx.font = "400 16px ui-sans-serif, system-ui, sans-serif"; ctx.fillText("Espace pour rejouer", W / 2, 140); ctx.globalAlpha = 1;
  }
  if (s.flash > 0) { ctx.fillStyle = ACCENT; ctx.globalAlpha = s.flash * 0.35; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
}

let last = performance.now();
function loop(now) {
  const k = Math.min((now - last) / 16.667, 2); last = now;
  update(k); draw(); requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
